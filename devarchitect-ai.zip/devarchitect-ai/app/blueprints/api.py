"""
DevArchitect AI - General API Blueprint (status, config, sessions)
"""
import os
from flask import Blueprint, jsonify, request, current_app
from app.utils.watsonx_client import get_watsonx_client
from app.services import session_service

api_bp = Blueprint("api", __name__)


@api_bp.route("/status", methods=["GET"])
def status():
    """Health check and watsonx.ai connectivity check."""
    client = get_watsonx_client()
    return jsonify({
        "status": "running",
        "watsonx_ready": client.is_ready(),
        "model": current_app.config.get("GRANITE_MODEL_ID"),
        "version": "1.0.0",
    })


@api_bp.route("/config/validate", methods=["POST"])
def validate_config():
    """Validate IBM watsonx.ai credentials."""
    data = request.get_json(force=True)
    api_key = data.get("api_key", "").strip()
    url = data.get("url", "").strip()
    project_id = data.get("project_id", "").strip()

    if not all([api_key, url, project_id]):
        return jsonify({"valid": False, "message": "All fields are required."}), 400

    from app.utils.watsonx_client import WatsonxClient
    test_client = WatsonxClient()
    model_id = current_app.config.get("GRANITE_MODEL_ID")
    code_model_id = current_app.config.get("GRANITE_CODE_MODEL_ID")
    ok, err = test_client.initialize(api_key, url, project_id, model_id, code_model_id)

    if ok:
        # Update global singleton
        WatsonxClient._instance = test_client
        return jsonify({"valid": True, "message": "IBM watsonx.ai credentials validated successfully."})
    return jsonify({"valid": False, "message": err or "Validation failed."}), 401


@api_bp.route("/sessions", methods=["GET"])
def list_sessions():
    return jsonify({"sessions": session_service.list_sessions()})


@api_bp.route("/sessions/<session_id>", methods=["GET"])
def get_session(session_id):
    session = session_service.get_session(session_id)
    if not session:
        return jsonify({"error": "Session not found"}), 404
    return jsonify({
        "id": session["id"],
        "repo_name": session.get("repo_name"),
        "repo_type": session.get("repo_type"),
        "status": session.get("status"),
        "created_at": session.get("created_at"),
    })


@api_bp.route("/sessions/<session_id>", methods=["DELETE"])
def delete_session(session_id):
    session_service.delete_session(session_id)
    from app.services.rag_service import RAGService
    from flask import current_app
    rag = RAGService(current_app.config["VECTOR_STORE_FOLDER"])
    rag.clear_session(session_id)
    return jsonify({"message": "Session deleted."})


@api_bp.route("/file/content", methods=["POST"])
def get_file_content():
    """Get content of a specific file in the repo."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    filepath = data.get("filepath")

    session = session_service.get_session(session_id)
    if not session or not session.get("repo_path"):
        return jsonify({"error": "Session or repository not found"}), 404

    import os
    full_path = os.path.join(session["repo_path"], filepath)
    # Security: prevent path traversal
    real_full = os.path.realpath(full_path)
    real_repo = os.path.realpath(session["repo_path"])
    if not real_full.startswith(real_repo):
        return jsonify({"error": "Invalid file path"}), 400

    if not os.path.isfile(full_path):
        return jsonify({"error": "File not found"}), 404

    from app.utils.repo_parser import safe_read_file, get_language
    content = safe_read_file(full_path)
    if content is None:
        return jsonify({"error": "Could not read file (too large or binary)"}), 400

    return jsonify({
        "path": filepath,
        "content": content,
        "language": get_language(filepath),
        "size": len(content),
    })
