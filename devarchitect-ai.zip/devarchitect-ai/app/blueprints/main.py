"""
DevArchitect AI - Main Blueprint (Page Routes)
"""
from flask import Blueprint, render_template

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    return render_template("index.html")


@main_bp.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@main_bp.route("/chat")
def chat():
    return render_template("chat.html")
