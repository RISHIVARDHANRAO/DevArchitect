"""
DevArchitect AI - Agents Blueprint (All 8 AI agents + RAG chat)
"""
import os
import logging
from flask import Blueprint, request, jsonify, current_app
from app.services import session_service
from app.utils.repo_parser import collect_files

logger = logging.getLogger(__name__)
agents_bp = Blueprint("agents", __name__)

# Lazy RAG service singleton
_rag_service = None


def get_rag_service():
    global _rag_service
    if _rag_service is None:
        from app.services.rag_service import RAGService
        _rag_service = RAGService(
            current_app.config["VECTOR_STORE_FOLDER"],
            current_app.config.get("EMBEDDING_MODEL", "all-MiniLM-L6-v2"),
        )
    return _rag_service


def _get_session_contents(session_id: str):
    """Load repository contents for a session."""
    session = session_service.get_session(session_id)
    if not session or not session.get("repo_path"):
        return None, None, "Session or repository not found."

    repo_path = session["repo_path"]
    if not os.path.exists(repo_path):
        return None, None, "Repository path no longer exists."

    supported = current_app.config["SUPPORTED_EXTENSIONS"]
    max_kb = current_app.config["MAX_FILE_SIZE_KB"]
    files, contents = collect_files(repo_path, supported, max_kb)
    return files, contents, None


@agents_bp.route("/analyze/repository", methods=["POST"])
def analyze_repository():
    """Run Repository Analysis Agent."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")

    files, contents, err = _get_session_contents(session_id)
    if err:
        return jsonify({"error": err}), 404

    from app.agents.repo_analysis_agent import RepositoryAnalysisAgent
    agent = RepositoryAnalysisAgent()
    result = agent.analyze(
        session_service.get_session(session_id)["repo_path"],
        current_app.config["SUPPORTED_EXTENSIONS"],
        current_app.config["MAX_FILE_SIZE_KB"],
    )

    session_service.set_analysis(session_id, "repository", result)
    session_service.update_session(session_id, status="analyzed")

    # Build RAG index in background
    try:
        rag = get_rag_service()
        rag.index_repository(
            session_id, contents,
            current_app.config.get("RAG_CHUNK_SIZE", 1000),
            current_app.config.get("RAG_CHUNK_OVERLAP", 200),
        )
        logger.info(f"RAG index built for session {session_id}")
    except Exception as e:
        logger.error(f"RAG indexing failed: {e}")

    return jsonify(result)


@agents_bp.route("/analyze/architecture", methods=["POST"])
def analyze_architecture():
    """Run Architecture Agent."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")

    files, contents, err = _get_session_contents(session_id)
    if err:
        return jsonify({"error": err}), 404

    repo_data = session_service.get_analysis(session_id, "repository") or {}

    from app.agents.architecture_agent import ArchitectureAgent
    agent = ArchitectureAgent()
    result = agent.analyze(repo_data, contents)
    session_service.set_analysis(session_id, "architecture", result)
    return jsonify(result)


@agents_bp.route("/analyze/code-review", methods=["POST"])
def analyze_code_review():
    """Run Code Review Agent."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")

    files, contents, err = _get_session_contents(session_id)
    if err:
        return jsonify({"error": err}), 404

    repo_data = session_service.get_analysis(session_id, "repository") or {}
    lang_dist = repo_data.get("language_distribution", [])

    from app.agents.code_review_agent import CodeReviewAgent
    agent = CodeReviewAgent()
    result = agent.review(contents, lang_dist)
    session_service.set_analysis(session_id, "code_review", result)
    return jsonify(result)


@agents_bp.route("/analyze/security", methods=["POST"])
def analyze_security():
    """Run Security Analysis Agent."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")

    files, contents, err = _get_session_contents(session_id)
    if err:
        return jsonify({"error": err}), 404

    from app.agents.security_agent import SecurityAnalysisAgent
    agent = SecurityAnalysisAgent()
    result = agent.analyze(contents)
    session_service.set_analysis(session_id, "security", result)
    return jsonify(result)


@agents_bp.route("/analyze/performance", methods=["POST"])
def analyze_performance():
    """Run Performance Optimization Agent."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")

    files, contents, err = _get_session_contents(session_id)
    if err:
        return jsonify({"error": err}), 404

    from app.agents.performance_agent import PerformanceAgent
    agent = PerformanceAgent()
    result = agent.analyze(contents)
    session_service.set_analysis(session_id, "performance", result)
    return jsonify(result)


@agents_bp.route("/analyze/documentation", methods=["POST"])
def analyze_documentation():
    """Run Documentation Agent."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")

    files, contents, err = _get_session_contents(session_id)
    if err:
        return jsonify({"error": err}), 404

    repo_data = session_service.get_analysis(session_id, "repository") or {}

    from app.agents.documentation_agent import DocumentationAgent
    agent = DocumentationAgent()
    result = agent.generate(repo_data, contents)
    session_service.set_analysis(session_id, "documentation", result)
    return jsonify(result)


@agents_bp.route("/analyze/tests", methods=["POST"])
def generate_tests():
    """Run Test Case Generation Agent."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")

    files, contents, err = _get_session_contents(session_id)
    if err:
        return jsonify({"error": err}), 404

    repo_data = session_service.get_analysis(session_id, "repository") or {}
    lang_dist = repo_data.get("language_distribution", [{}])
    primary_lang = lang_dist[0].get("language", "Python") if lang_dist else "Python"

    from app.agents.test_generation_agent import TestGenerationAgent
    agent = TestGenerationAgent()
    result = agent.generate(contents, primary_lang)
    session_service.set_analysis(session_id, "tests", result)
    return jsonify(result)


@agents_bp.route("/analyze/all", methods=["POST"])
def analyze_all():
    """Run all agents sequentially and return aggregated results."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")

    files, contents, err = _get_session_contents(session_id)
    if err:
        return jsonify({"error": err}), 404

    repo_path = session_service.get_session(session_id)["repo_path"]
    supported = current_app.config["SUPPORTED_EXTENSIONS"]
    max_kb = current_app.config["MAX_FILE_SIZE_KB"]
    results = {}

    # 1. Repository Analysis
    from app.agents.repo_analysis_agent import RepositoryAnalysisAgent
    results["repository"] = RepositoryAnalysisAgent().analyze(repo_path, supported, max_kb)
    session_service.set_analysis(session_id, "repository", results["repository"])

    # 2. Architecture
    from app.agents.architecture_agent import ArchitectureAgent
    results["architecture"] = ArchitectureAgent().analyze(results["repository"], contents)
    session_service.set_analysis(session_id, "architecture", results["architecture"])

    # 3. Code Review
    from app.agents.code_review_agent import CodeReviewAgent
    results["code_review"] = CodeReviewAgent().review(contents, results["repository"].get("language_distribution", []))
    session_service.set_analysis(session_id, "code_review", results["code_review"])

    # 4. Security
    from app.agents.security_agent import SecurityAnalysisAgent
    results["security"] = SecurityAnalysisAgent().analyze(contents)
    session_service.set_analysis(session_id, "security", results["security"])

    # 5. Performance
    from app.agents.performance_agent import PerformanceAgent
    results["performance"] = PerformanceAgent().analyze(contents)
    session_service.set_analysis(session_id, "performance", results["performance"])

    session_service.update_session(session_id, status="analyzed")

    # Build RAG index
    try:
        rag = get_rag_service()
        rag.index_repository(session_id, contents,
                              current_app.config.get("RAG_CHUNK_SIZE", 1000),
                              current_app.config.get("RAG_CHUNK_OVERLAP", 200))
    except Exception as e:
        logger.error(f"RAG indexing error: {e}")

    return jsonify(results)


@agents_bp.route("/chat", methods=["POST"])
def chat():
    """Repository Q&A Agent — multi-turn chat."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    message = (data.get("message") or "").strip()

    if not session_id or not message:
        return jsonify({"error": "session_id and message are required."}), 400

    repo_data = session_service.get_analysis(session_id, "repository") or {}
    if not repo_data:
        return jsonify({"error": "Repository not analyzed yet. Please run analysis first."}), 400

    session_service.add_chat_message(session_id, "user", message)
    history = session_service.get_chat_history(session_id)

    from app.agents.rag_qa_agent import RepositoryQAAgent
    agent = RepositoryQAAgent()
    rag = get_rag_service()
    response = agent.chat(history, repo_data, rag, session_id)

    session_service.add_chat_message(session_id, "assistant", response)
    return jsonify({
        "response": response,
        "sources": [],
        "history_length": len(history),
    })


@agents_bp.route("/explain/file", methods=["POST"])
def explain_file():
    """Explain a specific file using AI."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    filepath = data.get("filepath")

    session = session_service.get_session(session_id)
    if not session or not session.get("repo_path"):
        return jsonify({"error": "Session not found."}), 404

    full_path = os.path.join(session["repo_path"], filepath)
    real_full = os.path.realpath(full_path)
    real_repo = os.path.realpath(session["repo_path"])
    if not real_full.startswith(real_repo) or not os.path.isfile(full_path):
        return jsonify({"error": "File not found."}), 404

    from app.utils.repo_parser import safe_read_file, get_language
    content = safe_read_file(full_path)
    if not content:
        return jsonify({"error": "Could not read file."}), 400

    language = get_language(filepath)
    from app.utils.watsonx_client import get_watsonx_client
    from app.agents.agent_instructions import get_agent_system_prompt

    prompt = (
        f"{get_agent_system_prompt('rag_qa')}\n\n"
        f"Explain this {language} file in detail:\n\n"
        f"**File:** {filepath}\n"
        f"```{language.lower()}\n{content[:3000]}\n```\n\n"
        f"Provide:\n"
        f"1. **File Purpose** — what does this file do?\n"
        f"2. **Key Components** — classes, functions, and their responsibilities\n"
        f"3. **Dependencies** — what it imports and why\n"
        f"4. **Integration** — how it fits in the overall project\n"
        f"5. **Notable Patterns** — design patterns, algorithms used\n"
        f"6. **Potential Issues** — any concerns in this file\n"
    )

    client = get_watsonx_client()
    explanation = client.generate(prompt, use_code_model=True, max_tokens=2500)
    return jsonify({"filepath": filepath, "language": language, "explanation": explanation})


@agents_bp.route("/report/generate", methods=["POST"])
def generate_report():
    """Generate PDF/Markdown report."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")

    session = session_service.get_session(session_id)
    if not session:
        return jsonify({"error": "Session not found."}), 404

    analysis = session.get("analysis", {})
    if not analysis:
        return jsonify({"error": "No analysis data available. Run analysis first."}), 400

    from app.services.report_service import generate_pdf_report
    try:
        report_path = generate_pdf_report(session_id, analysis)
        filename = os.path.basename(report_path)
        return jsonify({"report_path": filename, "message": "Report generated successfully."})
    except Exception as e:
        return jsonify({"error": f"Report generation failed: {str(e)}"}), 500


@agents_bp.route("/report/download/<filename>", methods=["GET"])
def download_report(filename):
    """Serve generated report file."""
    from flask import send_from_directory
    reports_folder = current_app.config["REPORTS_FOLDER"]
    return send_from_directory(reports_folder, filename, as_attachment=True)


@agents_bp.route("/rag/stats", methods=["POST"])
def rag_stats():
    """Get RAG index stats for a session."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    rag = get_rag_service()
    return jsonify(rag.get_stats(session_id))
