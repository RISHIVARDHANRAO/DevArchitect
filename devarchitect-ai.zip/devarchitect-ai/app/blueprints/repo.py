"""
DevArchitect AI - Repository Upload & Import Blueprint
"""
import os
import uuid
from flask import Blueprint, request, jsonify, current_app
from werkzeug.utils import secure_filename
from app.services import session_service
from app.utils.git_utils import (
    clone_github_repo, extract_zip_upload,
    validate_github_url, get_repo_metadata
)

repo_bp = Blueprint("repo", __name__)


@repo_bp.route("/upload", methods=["POST"])
def upload_zip():
    """Handle ZIP file upload."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided."}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "No filename."}), 400

    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in current_app.config["ALLOWED_UPLOAD_EXTENSIONS"]:
        return jsonify({"error": "Only .zip files are supported."}), 400

    session_id = str(uuid.uuid4())
    upload_folder = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(os.path.join(upload_folder, session_id), exist_ok=True)

    project_name = secure_filename(file.filename.rsplit(".", 1)[0]) or "project"
    zip_path = os.path.join(upload_folder, session_id, secure_filename(file.filename))
    file.save(zip_path)

    repo_path, error = extract_zip_upload(zip_path, session_id, project_name)
    if error:
        return jsonify({"error": error}), 400

    # Cleanup uploaded zip
    try:
        os.remove(zip_path)
    except Exception:
        pass

    session_id_new = session_service.create_session()

    session_service.update_session(
        session_id_new,
        repo_path=repo_path,
        repo_name=project_name,
        repo_type="zip",
        status="uploaded",
    )

    return jsonify({
        "session_id": session_id_new,
        "repo_name": project_name,
        "repo_path": repo_path,
        "message": "Repository uploaded and extracted successfully.",
    })


@repo_bp.route("/github", methods=["POST"])
def import_github():
    """Clone a public GitHub repository."""
    data = request.get_json(force=True)
    github_url = (data.get("url") or "").strip()

    if not github_url:
        return jsonify({"error": "GitHub URL is required."}), 400

    parsed = validate_github_url(github_url)
    if not parsed:
        return jsonify({"error": "Invalid GitHub URL. Format: https://github.com/owner/repo"}), 400

    owner, repo_name = parsed
    session_id = session_service.create_session()

    repo_path, error = clone_github_repo(github_url, session_id)
    if error:
        session_service.delete_session(session_id)
        return jsonify({"error": error}), 400

    # Fetch GitHub metadata
    token = current_app.config.get("GITHUB_TOKEN", "")
    metadata = get_repo_metadata(owner, repo_name, token)

    session_service.update_session(
        session_id,
        repo_path=repo_path,
        repo_name=repo_name,
        repo_type="github",
        status="imported",
        github_metadata=metadata,
    )

    return jsonify({
        "session_id": session_id,
        "repo_name": repo_name,
        "owner": owner,
        "metadata": metadata,
        "message": f"Repository '{owner}/{repo_name}' imported successfully.",
    })


@repo_bp.route("/filetree", methods=["POST"])
def get_file_tree():
    """Get the file tree for a session's repository."""
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    session = session_service.get_session(session_id)

    if not session or not session.get("repo_path"):
        return jsonify({"error": "Session not found."}), 404

    from app.utils.repo_parser import build_file_tree
    tree = build_file_tree(session["repo_path"])
    return jsonify({"tree": tree})
