/**
 * DevArchitect AI — Dashboard JavaScript
 * Handles all dashboard interactions, agent calls, charts, and visualizations
 */

let langChart = null;
let metricsRadar = null;
let currentFile = null;

// ── Init ──────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', async () => {
  initCharts();
  const sessionId = getCurrentSessionId();
  if (sessionId) {
    loadDashboardForSession(sessionId);
  }

  // Check if redirected with target tab
  const targetTab = sessionStorage.getItem('da_target_tab');
  if (targetTab) {
    sessionStorage.removeItem('da_target_tab');
    switchTab(targetTab, null);
    if (sessionId) setTimeout(() => runAgent(targetTab), 500);
  }

  const runAllBtn = document.getElementById('runAllBtn');
  const reportBtn = document.getElementById('reportBtn');
  if (sessionId) {
    runAllBtn && (runAllBtn.disabled = false);
    reportBtn && (reportBtn.disabled = false);
  }
});

window.loadDashboardForSession = loadDashboardForSession;
window.runAgent = runAgent;
window.switchTab = switchTab;
window.generateDashboardReport = generateDashboardReport;

async function loadDashboardForSession(sessionId) {
  DA.currentSession = DA.currentSession || { id: sessionId };
  try {
    const res = await fetch(`/api/sessions/${sessionId}`);
    const data = await res.json();
    if (!res.ok) return;

    DA.currentSession = { ...DA.currentSession, ...data };
    updateSessionBadge(data.repo_name);
    document.getElementById('repoSubtitle').textContent = `Analyzing: ${data.repo_name}`;
    document.getElementById('repoType').textContent = data.repo_type === 'github' ? 'GitHub' : 'ZIP Upload';

    // Enable action buttons
    document.getElementById('runAllBtn').disabled = false;
    document.getElementById('reportBtn').disabled = false;

    // Load file tree
    await loadFileTree(sessionId);

    // Show repo meta
    renderRepoMeta(data);
  } catch (e) {
    showToast('Failed to load session data', 'error');
  }
}

async function loadFileTree(sessionId) {
  try {
    const data = await apiPost('/api/repo/filetree', { session_id: sessionId });
    renderFileTree(data.tree, document.getElementById('fileTree'), sessionId);
  } catch (e) {
    document.getElementById('fileTree').innerHTML = '<div class="text-muted text-center py-3 px-3 fs-sm">File tree unavailable</div>';
  }
}

function renderFileTree(node, container, sessionId, level = 0) {
  container.innerHTML = '';
  renderTreeNode(node, container, sessionId);
}

function renderTreeNode(node, container, sessionId) {
  if (!node) return;
  const wrapper = document.createElement('div');
  wrapper.className = 'tree-node';

  const row = document.createElement('div');
  row.className = 'tree-node-row';

  if (node.type === 'directory') {
    const toggleIcon = document.createElement('i');
    toggleIcon.className = 'bi bi-chevron-right tree-dir-toggle';
    const dirIcon = document.createElement('i');
    dirIcon.className = 'bi bi-folder-fill tree-dir-icon';
    const label = document.createElement('span');
    label.className = 'tree-node-label';
    label.textContent = node.name;

    row.appendChild(toggleIcon);
    row.appendChild(dirIcon);
    row.appendChild(label);

    const children = document.createElement('div');
    children.className = 'tree-children';
    children.style.display = 'none';

    row.onclick = () => {
      const isOpen = children.style.display !== 'none';
      children.style.display = isOpen ? 'none' : 'block';
      toggleIcon.className = isOpen ? 'bi bi-chevron-right tree-dir-toggle' : 'bi bi-chevron-down tree-dir-toggle';
      dirIcon.className = isOpen ? 'bi bi-folder-fill tree-dir-icon' : 'bi bi-folder2-open tree-dir-icon';
    };

    (node.children || []).forEach(child => renderTreeNode(child, children, sessionId));
    wrapper.appendChild(row);
    wrapper.appendChild(children);
  } else {
    const fileIcon = document.createElement('i');
    fileIcon.className = `bi ${getFileIcon(node.name)} tree-file-icon`;
    const label = document.createElement('span');
    label.className = 'tree-node-label';
    label.textContent = node.name;
    const sizeEl = document.createElement('span');
    sizeEl.className = 'ms-auto text-muted' ;
    sizeEl.style.fontSize = '10px';
    sizeEl.textContent = node.size ? formatBytes(node.size) : '';

    row.appendChild(fileIcon);
    row.appendChild(label);
    row.appendChild(sizeEl);
    row.dataset.filepath = node._fullPath || node.name;
    row.onclick = () => openFile(row.dataset.filepath, sessionId, node.language);
    wrapper.appendChild(row);
  }
  container.appendChild(wrapper);
}

// Pre-compute full paths
function addPaths(node, prefix = '') {
  const path = prefix ? prefix + '/' + node.name : node.name;
  node._fullPath = path;
  (node.children || []).forEach(c => addPaths(c, path === node.name ? '' : path));
}

function getFileIcon(filename) {
  const ext = filename.split('.').pop().toLowerCase();
  const icons = {
    py: 'bi-filetype-py', js: 'bi-filetype-js', ts: 'bi-filetype-tsx',
    jsx: 'bi-filetype-jsx', tsx: 'bi-filetype-tsx', html: 'bi-filetype-html',
    css: 'bi-filetype-css', json: 'bi-filetype-json', md: 'bi-filetype-md',
    yml: 'bi-file-earmark-code', yaml: 'bi-file-earmark-code',
    sh: 'bi-terminal', dockerfile: 'bi-box-seam',
    go: 'bi-file-earmark-code', java: 'bi-filetype-java',
    rs: 'bi-file-earmark-code', rb: 'bi-file-earmark-code',
    sql: 'bi-database', txt: 'bi-file-text', xml: 'bi-file-earmark-code',
    toml: 'bi-file-earmark-code', env: 'bi-gear',
  };
  return icons[ext] || 'bi-file-earmark';
}

function filterFileTree(query) {
  const rows = document.querySelectorAll('.tree-node-row');
  rows.forEach(row => {
    const label = row.querySelector('.tree-node-label');
    if (!label) return;
    const match = !query || label.textContent.toLowerCase().includes(query.toLowerCase());
    row.parentElement.style.display = match ? '' : 'none';
  });
}

// ── File Viewer ───────────────────────────────────────────────
async function openFile(filepath, sessionId, language) {
  if (!filepath || !sessionId) return;
  currentFile = filepath;

  try {
    const data = await apiPost('/api/file/content', { session_id: sessionId, filepath });
    const codeEl = document.getElementById('codeViewerContent');
    const titleEl = document.getElementById('codeViewerTitle');
    const metaEl = document.getElementById('codeViewerMeta');

    titleEl.textContent = filepath.split('/').pop();
    metaEl.textContent = `${filepath} · ${data.language} · ${formatBytes(data.size)}`;

    codeEl.textContent = data.content;
    codeEl.className = `language-${(data.language || '').toLowerCase().replace(/[^a-z]/g, '')}`;

    try { hljs.highlightElement(codeEl); } catch(e) {}

    new bootstrap.Modal(document.getElementById('codeViewerModal')).show();
  } catch (e) {
    showToast('Failed to load file: ' + e.message, 'error');
  }
}

async function explainCurrentFile() {
  if (!currentFile) return;
  const sessionId = getCurrentSessionId();
  if (!sessionId) return;

  const explanationModal = new bootstrap.Modal(document.getElementById('explanationModal'));
  const content = document.getElementById('explanationContent');
  content.innerHTML = '<div class="text-center py-4"><div class="analysis-spinner" style="width:32px;height:32px;border-width:3px;margin:0 auto 12px;"></div><div class="text-muted">AI is analyzing this file...</div></div>';
  explanationModal.show();

  try {
    const data = await apiPost('/api/agents/explain/file', { session_id: sessionId, filepath: currentFile });
    content.innerHTML = `<div class="prose-content">${renderMarkdown(data.explanation)}</div>`;
    highlightAllCode();
  } catch (e) {
    content.innerHTML = `<div class="text-danger">Failed to explain file: ${escapeHtml(e.message)}</div>`;
  }
}

// ── Run Agents ────────────────────────────────────────────────
async function runAgent(agentType) {
  const sessionId = getCurrentSessionId();
  if (!sessionId) {
    showToast('No repository loaded. Please upload or import a project first.', 'warning');
    return;
  }

  const btnId = `btn-${agentType}-agent`;
  const btn = document.getElementById(btnId);
  if (btn) { btn.classList.add('running'); btn.innerHTML = `<div class="spinner-border spinner-border-sm"></div><span>${btn.querySelector('span')?.textContent || ''}</span>`; }

  const endpoints = {
    'repository': '/api/agents/analyze/repository',
    'architecture': '/api/agents/analyze/architecture',
    'security': '/api/agents/analyze/security',
    'performance': '/api/agents/analyze/performance',
    'code-review': '/api/agents/analyze/code-review',
    'documentation': '/api/agents/analyze/documentation',
    'tests': '/api/agents/analyze/tests',
  };

  const endpoint = endpoints[agentType];
  if (!endpoint) return;

  switchTab(agentType, null);

  try {
    const data = await apiPost(endpoint, { session_id: sessionId });
    DA.analysisData[agentType] = data;

    switch (agentType) {
      case 'repository': renderRepositoryAnalysis(data); break;
      case 'architecture': renderArchitectureAnalysis(data); break;
      case 'security': renderSecurityAnalysis(data); break;
      case 'performance': renderPerformanceAnalysis(data); break;
      case 'code-review': renderCodeReviewAnalysis(data); break;
      case 'documentation': renderDocumentationAnalysis(data); break;
      case 'tests': renderTestsAnalysis(data); break;
    }

    if (btn) { btn.classList.remove('running'); btn.classList.add('done'); }
    showToast(`${agentType.charAt(0).toUpperCase() + agentType.slice(1)} analysis complete!`, 'success');
  } catch (e) {
    if (btn) { btn.classList.remove('running'); }
    showToast(`Analysis failed: ${e.message}`, 'error');
  }
}

async function runAllAgents() {
  const sessionId = getCurrentSessionId();
  if (!sessionId) { showToast('No repository loaded', 'warning'); return; }

  document.getElementById('runAllBtn').disabled = true;
  document.getElementById('globalLoader').style.display = 'flex';
  document.getElementById('loaderText').textContent = 'Running All 8 AI Agents';
  document.getElementById('loaderSubtext').textContent = 'This may take 1-3 minutes...';

  try {
    const data = await apiPost('/api/agents/analyze/all', { session_id: sessionId });

    if (data.repository) {
      DA.analysisData.repository = data.repository;
      renderRepositoryAnalysis(data.repository);
    }
    if (data.architecture) {
      DA.analysisData.architecture = data.architecture;
      renderArchitectureAnalysis(data.architecture);
    }
    if (data.security) {
      DA.analysisData.security = data.security;
      renderSecurityAnalysis(data.security);
    }
    if (data.performance) {
      DA.analysisData.performance = data.performance;
      renderPerformanceAnalysis(data.performance);
    }
    if (data.code_review) {
      DA.analysisData['code-review'] = data.code_review;
      renderCodeReviewAnalysis(data.code_review);
    }

    document.getElementById('globalLoader').style.display = 'none';
    document.getElementById('runAllBtn').disabled = false;
    showToast('All agents completed successfully!', 'success');
    switchTab('summary', null);
    renderSummaryTab();
  } catch (e) {
    document.getElementById('globalLoader').style.display = 'none';
    document.getElementById('runAllBtn').disabled = false;
    showToast('Analysis failed: ' + e.message, 'error');
  }
}

// ── Tab Navigation ────────────────────────────────────────────
function switchTab(tabName, link) {
  // Update panels
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  const panel = document.getElementById(`tab-${tabName}`);
  if (panel) panel.classList.add('active');

  // Update tab links
  document.querySelectorAll('.card-tabs .nav-link').forEach(l => {
    l.classList.remove('active');
    if (l.dataset.tab === tabName) l.classList.add('active');
  });
}

// ── Render: Repository Analysis ───────────────────────────────
function renderRepositoryAnalysis(data) {
  const health = data.health_score || {};

  // Health banner
  document.getElementById('healthBanner').style.display = '';
  document.getElementById('healthOverall').textContent = health.overall || 0;
  document.getElementById('healthGrade').textContent = `Grade ${health.grade || '—'}`;
  document.getElementById('healthGrade').style.color = getGradeColor(health.grade);

  const sec = DA.analysisData.security?.risk_score;
  const rev = DA.analysisData['code-review']?.quality_score;
  const perf = DA.analysisData.performance?.performance_score;
  if (sec) document.getElementById('securityScore').textContent = sec.score;
  if (rev) document.getElementById('qualityScore').textContent = rev.score;
  if (perf) document.getElementById('perfScore').textContent = perf;

  // Language chart
  updateLanguageChart(data.language_distribution || []);

  // Tech stack
  renderTechStack(data.frameworks || [], data.primary_language);

  // Dependencies widget
  renderDependencies(data.dependencies || {});

  // Repo meta
  renderRepoMeta({ ...data, ...DA.currentSession });

  // Summary tab
  const summaryEl = document.getElementById('summaryContent');
  summaryEl.innerHTML = `
    <div class="row g-3 mb-3">
      <div class="col-4">
        <div class="metric-box"><div class="metric-value">${formatNumber(data.total_files)}</div><div class="metric-label">Files</div></div>
      </div>
      <div class="col-4">
        <div class="metric-box"><div class="metric-value">${formatNumber(data.total_lines)}</div><div class="metric-label">Lines</div></div>
      </div>
      <div class="col-4">
        <div class="metric-box"><div class="metric-value">${data.total_size_kb || 0} KB</div><div class="metric-label">Size</div></div>
      </div>
    </div>
    ${data.ai_summary ? `<div class="prose-content">${renderMarkdown(data.ai_summary)}</div>` : ''}
    <div class="mt-3">
      <strong>License:</strong> <span class="tech-tag">${data.license || 'Unknown'}</span>
      ${health.has_readme ? '<span class="tech-tag text-success"><i class="bi bi-check-lg me-1"></i>README</span>' : '<span class="tech-tag text-warning"><i class="bi bi-x-lg me-1"></i>No README</span>'}
      ${health.has_tests ? '<span class="tech-tag text-success"><i class="bi bi-check-lg me-1"></i>Tests</span>' : '<span class="tech-tag text-warning"><i class="bi bi-x-lg me-1"></i>No Tests</span>'}
      ${health.has_ci ? '<span class="tech-tag text-success"><i class="bi bi-check-lg me-1"></i>CI/CD</span>' : ''}
    </div>
    ${data.api_endpoints?.length ? `<div class="mt-3"><strong>API Endpoints (${data.api_endpoints.length}):</strong><div class="mt-2">${data.api_endpoints.slice(0,8).map(e => `<code class="me-1 mb-1" style="display:inline-block;">${escapeHtml(e.path)}</code>`).join('')}</div></div>` : ''}
  `;
  highlightAllCode();
}

// ── Render: Architecture ──────────────────────────────────────
function renderArchitectureAnalysis(data) {
  const container = document.getElementById('architectureContent');
  const mermaidId = 'arch-mermaid-' + Date.now();

  container.innerHTML = `
    <div class="prose-content mb-3">${renderMarkdown(data.ai_analysis || '')}</div>
    ${data.mermaid_diagram ? `
      <h6 class="fw-600 mt-3 mb-2"><i class="bi bi-diagram-3 me-2"></i>Architecture Diagram</h6>
      <div class="mermaid-container mb-3" id="${mermaidId}">Loading diagram...</div>
    ` : ''}
    ${data.patterns_detected?.length ? `
      <div class="mt-3">
        <strong>Detected Patterns:</strong>
        <div class="mt-2">${data.patterns_detected.map(p => `<span class="tech-tag">${escapeHtml(p)}</span>`).join('')}</div>
      </div>
    ` : ''}
  `;

  if (data.mermaid_diagram) {
    setTimeout(() => renderMermaid(mermaidId, data.mermaid_diagram), 200);
  }
  highlightAllCode();
}

// ── Render: Security Analysis ─────────────────────────────────
function renderSecurityAnalysis(data) {
  const container = document.getElementById('securityContent');
  const risk = data.risk_score || {};
  const findings = data.findings || [];
  const stats = data.statistics || {};

  // Update health banner
  if (risk.score !== undefined) {
    document.getElementById('securityScore').textContent = risk.score;
    document.getElementById('securityScore').style.color = getGradeColor(risk.grade);
  }

  // Security widget
  const widgetEl = document.getElementById('securityWidgetContent');
  widgetEl.innerHTML = `
    <div class="d-flex align-items-center gap-2 mb-2">
      <div class="score-circle ${getScoreClass(risk.score || 0)}" style="width:50px;height:50px;font-size:16px;">${risk.score || 0}</div>
      <div>
        <div class="fw-600">Grade ${risk.grade || '—'}</div>
        <div class="text-muted fs-sm">${risk.risk_level || '—'} Risk</div>
      </div>
    </div>
    ${Object.entries(stats).filter(([k,v]) => v > 0).map(([sev, count]) =>
      `<div class="d-flex justify-content-between mb-1"><span class="severity-badge ${severityClass(sev)}">${sev}</span><span class="fw-600">${count}</span></div>`
    ).join('')}
  `;

  container.innerHTML = `
    <div class="d-flex align-items-center gap-3 mb-3">
      <div class="score-circle ${getScoreClass(risk.score || 0)}">${risk.score || 0}</div>
      <div>
        <div class="fw-700">Security Score: Grade ${risk.grade || '—'}</div>
        <div class="text-muted fs-sm">Risk Level: <strong style="color:${risk.risk_level === 'Low' ? '#2ea043' : risk.risk_level === 'Medium' ? '#d29922' : '#da3633'}">${risk.risk_level || 'Unknown'}</strong></div>
        <div class="text-muted fs-sm">${data.total_findings || 0} total findings</div>
      </div>
    </div>
    <div class="prose-content mb-3">${renderMarkdown(data.ai_report || '')}</div>
    <h6 class="fw-600 mb-2"><i class="bi bi-list-check me-2"></i>Findings (${findings.length})</h6>
    ${findings.slice(0, 20).map(f => `
      <div class="finding-item ${severityBorderClass(f.severity)}">
        <div class="d-flex align-items-center gap-2 mb-1">
          <span class="severity-badge ${severityClass(f.severity)}">${f.severity}</span>
          <strong class="fs-sm">${escapeHtml(f.type)}</strong>
          <span class="text-muted fs-sm ms-auto">${escapeHtml(f.file)}:${f.line}</span>
        </div>
        ${f.code_snippet ? `<code class="d-block fs-sm text-muted mb-1">${escapeHtml(f.code_snippet)}</code>` : ''}
        <div class="fs-sm"><i class="bi bi-wrench me-1 text-info"></i>${escapeHtml(f.remediation || '')}</div>
        ${f.cwe ? `<span class="tech-tag mt-1">${f.cwe}</span>` : ''}
        ${f.owasp ? `<span class="tech-tag mt-1">${f.owasp}</span>` : ''}
      </div>
    `).join('')}
  `;
  highlightAllCode();
}

// ── Render: Performance Analysis ──────────────────────────────
function renderPerformanceAnalysis(data) {
  const container = document.getElementById('performanceContent');
  const score = data.performance_score || 0;
  const stats = data.statistics || {};
  const findings = data.findings || [];
  const hotspots = data.hotspots || [];

  if (score !== undefined) {
    document.getElementById('perfScore').textContent = score;
  }

  container.innerHTML = `
    <div class="d-flex align-items-center gap-3 mb-3">
      <div class="score-circle ${getScoreClass(score)}">${score}</div>
      <div>
        <div class="fw-700">Performance Score</div>
        <div class="text-muted fs-sm">${data.total_findings || 0} findings</div>
      </div>
    </div>
    ${hotspots.length ? `
      <div class="mb-3">
        <h6 class="fw-600 mb-2"><i class="bi bi-fire me-2 text-danger"></i>Performance Hotspots</h6>
        ${hotspots.slice(0, 5).map(h => `
          <div class="finding-item medium">
            <div class="fw-600 fs-sm">${escapeHtml(h.file)}</div>
            <div class="text-muted fs-sm">${h.findings_count} issues · Score: ${h.score}</div>
          </div>
        `).join('')}
      </div>
    ` : ''}
    <div class="prose-content mb-3">${renderMarkdown(data.ai_report || '')}</div>
    <h6 class="fw-600 mb-2"><i class="bi bi-list-check me-2"></i>Performance Issues</h6>
    ${findings.slice(0, 15).map(f => `
      <div class="finding-item ${severityBorderClass(f.severity)}">
        <div class="d-flex align-items-center gap-2 mb-1">
          <span class="severity-badge ${severityClass(f.severity)}">${f.severity}</span>
          <strong class="fs-sm">${escapeHtml(f.type)}</strong>
          <span class="text-muted fs-sm ms-auto">${escapeHtml(f.file)}:${f.line || ''}</span>
        </div>
        <div class="fs-sm text-muted mb-1">${escapeHtml(f.description || '')}</div>
        <div class="fs-sm"><i class="bi bi-lightning-charge me-1 text-warning"></i>${escapeHtml(f.fix || '')}</div>
        ${f.big_o_improvement ? `<div class="mt-1"><span class="tech-tag"><i class="bi bi-graph-up me-1"></i>${escapeHtml(f.big_o_improvement)}</span></div>` : ''}
      </div>
    `).join('')}
  `;
  highlightAllCode();
}

// ── Render: Code Review ───────────────────────────────────────
function renderCodeReviewAnalysis(data) {
  const container = document.getElementById('codeReviewContent');
  const quality = data.quality_score || {};
  const issues = data.issues || [];
  const smells = data.code_smells || [];
  const dups = data.duplicates || [];

  if (quality.score !== undefined) {
    document.getElementById('qualityScore').textContent = quality.score;
  }

  // Metrics radar
  updateMetricsRadar(quality.breakdown || {});

  container.innerHTML = `
    <div class="d-flex align-items-center gap-3 mb-3">
      <div class="score-circle ${getScoreClass(quality.score || 0)}">${quality.score || 0}</div>
      <div>
        <div class="fw-700">Code Quality: Grade ${quality.grade || '—'}</div>
        <div class="text-muted fs-sm">${data.total_issues || 0} issues · ${dups.length} duplicates · ${smells.length} code smells</div>
      </div>
    </div>
    <div class="prose-content mb-3">${renderMarkdown(data.ai_review || '')}</div>

    ${smells.length ? `
      <h6 class="fw-600 mb-2"><i class="bi bi-bug me-2 text-warning"></i>Code Smells</h6>
      ${smells.slice(0, 8).map(s => `
        <div class="finding-item medium">
          <div class="fw-600 fs-sm">${escapeHtml(s.smell)}</div>
          <div class="text-muted fs-sm">${escapeHtml(s.file)}</div>
          <div class="fs-sm mt-1">${escapeHtml(s.recommendation || '')}</div>
        </div>
      `).join('')}
    ` : ''}

    ${dups.length ? `
      <h6 class="fw-600 mb-2 mt-3"><i class="bi bi-copy me-2 text-info"></i>Code Duplication</h6>
      ${dups.slice(0, 5).map(d => `
        <div class="finding-item low">
          <div class="fw-600 fs-sm">${d.similarity}% similar</div>
          <div class="text-muted fs-sm">${escapeHtml(d.file_a)} ↔ ${escapeHtml(d.file_b)}</div>
          <div class="fs-sm">${escapeHtml(d.recommendation || '')}</div>
        </div>
      `).join('')}
    ` : ''}

    <h6 class="fw-600 mb-2 mt-3"><i class="bi bi-exclamation-triangle me-2"></i>Issues (${issues.length})</h6>
    ${issues.slice(0, 20).map(i => `
      <div class="finding-item ${severityBorderClass(i.severity)}">
        <div class="d-flex align-items-center gap-2 mb-1">
          <span class="severity-badge ${severityClass(i.severity)}">${i.severity}</span>
          <strong class="fs-sm">${escapeHtml(i.type)}</strong>
          <span class="text-muted fs-sm ms-auto">${escapeHtml(i.file)}:${i.line || ''}</span>
        </div>
        <div class="fs-sm">${escapeHtml(i.message || '')}</div>
      </div>
    `).join('')}
  `;
  highlightAllCode();
}

// ── Render: Documentation ─────────────────────────────────────
function renderDocumentationAnalysis(data) {
  const container = document.getElementById('documentationContent');
  const quality = data.doc_quality || {};

  container.innerHTML = `
    <div class="d-flex align-items-center gap-3 mb-3">
      <div class="score-circle ${getScoreClass(quality.score || 0)}">${quality.score || 0}</div>
      <div>
        <div class="fw-700">Documentation Quality: Grade ${quality.grade || '—'}</div>
        <div class="text-muted fs-sm">${data.existing_docs?.length || 0} existing doc files</div>
      </div>
    </div>
    ${quality.missing?.length ? `
      <div class="alert alert-warning py-2 px-3 mb-3 fs-sm">
        <strong>Missing:</strong> ${quality.missing.join(', ')}
      </div>
    ` : ''}

    <ul class="nav nav-tabs mb-3" id="docTabs">
      <li class="nav-item"><a class="nav-link active" data-dtab="readme" onclick="switchDocTab('readme',this)">README</a></li>
      <li class="nav-item"><a class="nav-link" data-dtab="api" onclick="switchDocTab('api',this)">API Docs</a></li>
      <li class="nav-item"><a class="nav-link" data-dtab="modules" onclick="switchDocTab('modules',this)">Modules</a></li>
      <li class="nav-item"><a class="nav-link" data-dtab="install" onclick="switchDocTab('install',this)">Install Guide</a></li>
    </ul>

    <div id="doc-tab-readme" class="doc-tab-panel active">
      <div class="d-flex justify-content-end mb-2">
        <button class="btn btn-sm btn-outline-secondary" onclick="copyText('doc-readme-content')"><i class="bi bi-clipboard me-1"></i>Copy</button>
      </div>
      <div class="prose-content" id="doc-readme-content">${renderMarkdown(data.readme || 'No README generated.')}</div>
    </div>
    <div id="doc-tab-api" class="doc-tab-panel" style="display:none;">
      <div class="prose-content">${renderMarkdown(data.api_docs || 'No API endpoints found.')}</div>
    </div>
    <div id="doc-tab-modules" class="doc-tab-panel" style="display:none;">
      <div class="prose-content">${renderMarkdown(data.module_docs || 'No module documentation generated.')}</div>
    </div>
    <div id="doc-tab-install" class="doc-tab-panel" style="display:none;">
      <div class="prose-content">${renderMarkdown(data.install_guide || 'No installation guide generated.')}</div>
    </div>
  `;
  highlightAllCode();
}

function switchDocTab(tabName, link) {
  document.querySelectorAll('.doc-tab-panel').forEach(p => p.style.display = 'none');
  const panel = document.getElementById(`doc-tab-${tabName}`);
  if (panel) panel.style.display = 'block';
  document.querySelectorAll('#docTabs .nav-link').forEach(l => {
    l.classList.toggle('active', l.dataset.dtab === tabName);
  });
}

function copyText(elId) {
  const el = document.getElementById(elId);
  if (el) {
    navigator.clipboard.writeText(el.textContent).then(() => showToast('Copied to clipboard!', 'success'));
  }
}

// ── Render: Test Generation ───────────────────────────────────
function renderTestsAnalysis(data) {
  const container = document.getElementById('testsContent');
  const coverage = data.coverage_analysis || {};
  const tests = data.generated_tests || [];

  container.innerHTML = `
    <div class="d-flex align-items-center gap-3 mb-3">
      <div class="score-circle ${getScoreClass(coverage.estimated_coverage || 0)}">${coverage.estimated_coverage || 0}%</div>
      <div>
        <div class="fw-700">Estimated Coverage: Grade ${coverage.grade || '—'}</div>
        <div class="text-muted fs-sm">${coverage.tested_units || 0} tested / ${coverage.total_units || 0} total units</div>
      </div>
    </div>
    <div class="prose-content mb-3">${renderMarkdown(data.edge_case_summary || '')}</div>
    <h6 class="fw-600 mb-2"><i class="bi bi-file-earmark-code me-2"></i>Generated Test Cases</h6>
    ${tests.map(t => `
      <div class="mb-3">
        <div class="d-flex align-items-center gap-2 mb-2">
          <span class="tech-tag"><i class="bi bi-file-earmark-code me-1"></i>${escapeHtml(t.source_file)}</span>
          <span class="tech-tag">${escapeHtml(t.test_framework)}</span>
          <span class="tech-tag">~${t.test_count_estimate || 0} tests</span>
        </div>
        <pre><code class="language-python">${escapeHtml(t.test_code || '')}</code></pre>
      </div>
    `).join('')}
  `;
  highlightAllCode();
}

// ── Summary Tab ───────────────────────────────────────────────
function renderSummaryTab() {
  // Already handled in renderRepositoryAnalysis
}

// ── Charts ────────────────────────────────────────────────────
function initCharts() {
  const langCtx = document.getElementById('langChart');
  if (langCtx) {
    langChart = new Chart(langCtx, {
      type: 'doughnut',
      data: { labels: [], datasets: [{ data: [], backgroundColor: [], borderWidth: 2, borderColor: [] }] },
      options: {
        plugins: { legend: { position: 'right', labels: { boxWidth: 12, font: { size: 11 } } } },
        responsive: true, maintainAspectRatio: false,
        cutout: '70%',
      }
    });
    document.getElementById('langChartEmpty').style.display = 'block';
  }

  const radarCtx = document.getElementById('metricsRadar');
  if (radarCtx) {
    metricsRadar = new Chart(radarCtx, {
      type: 'radar',
      data: {
        labels: ['Maintainability', 'Complexity', 'Duplication', 'Issues'],
        datasets: [{
          label: 'Code Quality',
          data: [0, 0, 0, 0],
          borderColor: '#3b82d4', backgroundColor: 'rgba(59,130,212,.15)',
          pointBackgroundColor: '#3b82d4',
        }],
      },
      options: {
        scales: { r: { min: 0, max: 100, ticks: { stepSize: 25, font: { size: 10 } }, pointLabels: { font: { size: 10 } } } },
        plugins: { legend: { display: false } },
        responsive: true, maintainAspectRatio: true,
      }
    });
  }
}

function updateLanguageChart(distribution) {
  if (!langChart || !distribution.length) return;
  langChart.data.labels = distribution.map(d => d.language);
  langChart.data.datasets[0].data = distribution.map(d => d.percentage);
  langChart.data.datasets[0].backgroundColor = distribution.map(d => getLangColor(d.language) + 'cc');
  langChart.data.datasets[0].borderColor = distribution.map(d => getLangColor(d.language));
  langChart.update();
  document.getElementById('langChartEmpty').style.display = 'none';
}

function updateMetricsRadar(breakdown) {
  if (!metricsRadar) return;
  metricsRadar.data.datasets[0].data = [
    breakdown.maintainability || 0,
    breakdown.complexity || 0,
    breakdown.duplication || 0,
    breakdown.issues || 0,
  ];
  metricsRadar.update();
}

// ── Render Repo Meta ──────────────────────────────────────────
function renderRepoMeta(data) {
  const container = document.getElementById('repoMeta');
  if (!container) return;
  const meta = [
    ['Name', data.repo_name || '—'],
    ['Type', data.repo_type === 'github' ? 'GitHub' : 'ZIP Upload'],
    ['Files', formatNumber(data.total_files)],
    ['Lines', formatNumber(data.total_lines)],
    ['Size', data.total_size_kb ? `${data.total_size_kb} KB` : '—'],
    ['Language', data.primary_language || '—'],
    ['License', data.license || '—'],
  ];
  container.innerHTML = meta.map(([k, v]) => `
    <div class="repo-meta-item">
      <span class="repo-meta-label">${k}</span>
      <span class="repo-meta-value">${escapeHtml(String(v))}</span>
    </div>
  `).join('');
}

// ── Render Tech Stack ─────────────────────────────────────────
function renderTechStack(frameworks, primaryLang) {
  const container = document.getElementById('techStackContent');
  if (!container) return;
  const tags = [];
  if (primaryLang) tags.push(`<span class="tech-tag" style="border-color:${getLangColor(primaryLang)}40;"><i class="bi bi-code me-1"></i>${escapeHtml(primaryLang)}</span>`);
  frameworks.forEach(f => tags.push(`<span class="tech-tag"><i class="bi bi-boxes me-1"></i>${escapeHtml(f)}</span>`));
  container.innerHTML = tags.length ? tags.join('') : '<div class="text-muted fs-sm">No frameworks detected</div>';
}

// ── Render Dependencies ───────────────────────────────────────
function renderDependencies(deps) {
  const container = document.getElementById('depsWidgetContent');
  if (!container) return;
  if (!Object.keys(deps).length) {
    container.innerHTML = '<div class="text-muted fs-sm text-center py-2">No manifest files found</div>';
    return;
  }
  container.innerHTML = Object.entries(deps).map(([manager, packages]) => `
    <div class="mb-2">
      <div class="fs-sm fw-600 mb-1">${escapeHtml(manager)}</div>
      <div class="d-flex align-items-center gap-1">
        <div class="progress flex-grow-1" style="height:6px;">
          <div class="progress-bar" style="width:${Math.min(packages.length * 3, 100)}%;background:var(--accent);"></div>
        </div>
        <span class="fs-tiny text-muted">${packages.length} pkgs</span>
      </div>
      <div class="mt-1">${packages.slice(0, 6).map(p => `<span class="tech-tag" style="font-size:10px;">${escapeHtml(p)}</span>`).join('')}${packages.length > 6 ? `<span class="text-muted fs-tiny"> +${packages.length - 6} more</span>` : ''}</div>
    </div>
  `).join('<hr class="my-2">');
}

// ── Report Generation ─────────────────────────────────────────
async function generateDashboardReport() {
  const sessionId = getCurrentSessionId();
  if (!sessionId) { showToast('No session to generate report for', 'warning'); return; }

  const btn = document.getElementById('reportBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Generating...';

  try {
    const data = await apiPost('/api/agents/report/generate', { session_id: sessionId });
    showToast('Report generated! Downloading...', 'success');
    window.open(`/api/agents/report/download/${data.report_path}`, '_blank');
  } catch (e) {
    showToast('Report generation failed: ' + e.message, 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="bi bi-file-earmark-pdf me-1"></i>Export Report';
  }
}

// ── CSS for metric boxes ──────────────────────────────────────
const style = document.createElement('style');
style.textContent = `
  .metric-box { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 10px; text-align: center; }
  .metric-value { font-size: 18px; font-weight: 800; color: var(--text); }
  .metric-label { font-size: 10.5px; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
`;
document.head.appendChild(style);
