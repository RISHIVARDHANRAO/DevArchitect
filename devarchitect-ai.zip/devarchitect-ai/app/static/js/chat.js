/**
 * DevArchitect AI — Chat JavaScript
 * Multi-turn RAG-powered chat with repository context
 */

let messageCount = 0;

// ── Init ──────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', async () => {
  await checkWatsonxStatus();
  loadSessionHistory();
  initChatSession();
});

function initChatSession() {
  const session = DA.currentSession;
  const sessionId = getCurrentSessionId();

  if (session && session.repo_name) {
    // Update context card
    document.getElementById('chatContextInfo').innerHTML = `
      <div class="d-flex align-items-center gap-2 mb-2">
        <i class="bi bi-${session.repo_type === 'github' ? 'github' : 'file-earmark-zip'} text-accent"></i>
        <strong>${escapeHtml(session.repo_name)}</strong>
      </div>
      <div class="text-muted fs-tiny">${session.repo_type === 'github' ? 'GitHub Repository' : 'ZIP Upload'}</div>
    `;

    document.getElementById('chatSessionId').textContent = sessionId ? sessionId.substring(0, 8) + '...' : '—';
    updateSessionBadge(session.repo_name);

    if (sessionId) {
      loadRAGStats(sessionId);
    }
  }

  // Input focus
  document.getElementById('chatInput').focus();
}

async function loadRAGStats(sessionId) {
  try {
    const data = await apiPost('/api/agents/rag/stats', { session_id: sessionId });
    if (data.indexed) {
      const card = document.getElementById('ragStatsCard');
      card.style.display = '';
      document.getElementById('ragChunks').textContent = `${data.chunk_count} chunks indexed`;
    }
  } catch (e) {}
}

// ── Chat Input ────────────────────────────────────────────────
function handleChatKeydown(event) {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    sendChatMessage();
  }
}

function autoResizeTextarea(textarea) {
  textarea.style.height = 'auto';
  textarea.style.height = Math.min(textarea.scrollHeight, 160) + 'px';
}

function sendSuggestion(btn) {
  const text = btn.textContent;
  document.getElementById('chatInput').value = text;
  sendChatMessage();
}

function insertCodeBlock() {
  const input = document.getElementById('chatInput');
  const cursor = input.selectionStart;
  const before = input.value.substring(0, cursor);
  const after = input.value.substring(cursor);
  input.value = before + '\n```\n\n```\n' + after;
  input.selectionStart = input.selectionEnd = cursor + 5;
  input.focus();
}

function insertFileRef() {
  const input = document.getElementById('chatInput');
  const fileRef = prompt('Enter file path (e.g. src/app.py):');
  if (fileRef) {
    input.value += `\nFile: \`${fileRef}\`\n`;
    input.focus();
  }
}

function clearChat() {
  const messages = document.getElementById('chatMessages');
  // Keep only first welcome message
  const allMessages = messages.querySelectorAll('.message');
  Array.from(allMessages).slice(1).forEach(m => m.remove());
  messageCount = 0;
  document.getElementById('chatMsgCount').textContent = '0';
}

// ── Send Message ──────────────────────────────────────────────
async function sendChatMessage() {
  const input = document.getElementById('chatInput');
  const message = input.value.trim();
  if (!message) return;

  const sessionId = getCurrentSessionId();
  if (!sessionId) {
    showToast('No repository loaded. Please upload a project first.', 'warning');
    return;
  }

  // Disable send while processing
  const sendBtn = document.getElementById('sendBtn');
  sendBtn.disabled = true;
  input.value = '';
  autoResizeTextarea(input);

  // Append user message
  appendMessage('user', message);
  messageCount++;
  document.getElementById('chatMsgCount').textContent = messageCount;

  // Show thinking indicator
  const typingId = appendTypingIndicator();
  showThinkingIndicator(true);

  try {
    const data = await apiPost('/api/agents/chat', {
      session_id: sessionId,
      message: message,
    });

    removeTypingIndicator(typingId);
    showThinkingIndicator(false);

    appendMessage('assistant', data.response, data.sources || []);
    messageCount++;
    document.getElementById('chatMsgCount').textContent = messageCount;

    // Scroll to bottom
    scrollToBottom();
  } catch (e) {
    removeTypingIndicator(typingId);
    showThinkingIndicator(false);
    appendMessage('assistant', `⚠️ Error: ${e.message}. Please ensure the repository is analyzed first.`, []);
  } finally {
    sendBtn.disabled = false;
    input.focus();
  }
}

// ── Message Rendering ─────────────────────────────────────────
function appendMessage(role, content, sources = []) {
  const container = document.getElementById('chatMessages');
  const isUser = role === 'user';
  const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const sourcesHtml = sources?.length ? `
    <div class="message-sources mt-2">
      <div class="text-muted fs-tiny mb-1"><i class="bi bi-search me-1"></i>Sources:</div>
      ${sources.map(s => `<span class="source-chip"><i class="bi bi-file-earmark-code me-1"></i>${escapeHtml(s.file)}</span>`).join('')}
    </div>
  ` : '';

  const contentHtml = isUser
    ? `<p>${escapeHtml(content)}</p>`
    : `<div class="prose-content">${renderMarkdown(content)}</div>`;

  const html = `
    <div class="message ${isUser ? 'user-message' : 'assistant-message'}">
      <div class="message-avatar">
        <i class="bi bi-${isUser ? 'person-fill' : 'cpu-fill'}"></i>
      </div>
      <div class="message-bubble">
        <div class="message-header">
          <span class="fw-600">${isUser ? 'You' : 'DevArchitect AI'}</span>
          <span class="message-time">${now}</span>
        </div>
        <div class="message-content">
          ${contentHtml}
          ${sourcesHtml}
        </div>
      </div>
    </div>
  `;

  container.insertAdjacentHTML('beforeend', html);

  // Highlight code
  container.querySelectorAll('pre code:not(.hljs)').forEach(block => {
    try { hljs.highlightElement(block); } catch (e) {}
  });

  scrollToBottom();
  return container.lastElementChild;
}

function appendTypingIndicator() {
  const container = document.getElementById('chatMessages');
  const id = 'typing-' + Date.now();
  const html = `
    <div class="message assistant-message typing-message" id="${id}">
      <div class="message-avatar"><i class="bi bi-cpu-fill"></i></div>
      <div class="message-bubble">
        <div class="typing-dots">
          <span></span><span></span><span></span>
        </div>
      </div>
    </div>
  `;
  container.insertAdjacentHTML('beforeend', html);
  scrollToBottom();
  return id;
}

function removeTypingIndicator(id) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

function showThinkingIndicator(show) {
  const el = document.getElementById('thinkingIndicator');
  if (el) el.classList.toggle('d-none', !show);
}

function scrollToBottom() {
  const container = document.getElementById('chatMessages');
  requestAnimationFrame(() => {
    container.scrollTop = container.scrollHeight;
  });
}
