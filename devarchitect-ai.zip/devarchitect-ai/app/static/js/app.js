/**
 * DevArchitect AI — Main Application JavaScript
 * Shared utilities, theme, uploads, and navigation
 */

// ── Global State ────────────────────────────────────────────
window.DA = window.DA || {
  currentSession: null,
  sessions: [],
  analysisData: {},
  charts: {},
  mermaidInitialized: false,
};

// ── Initialization ───────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  checkWatsonxStatus();
  loadSessionHistory();
  initMermaid();

  // Restore last session
  const lastSession = localStorage.getItem('da_last_session');
  if (lastSession) {
    try {
      DA.currentSession = JSON.parse(lastSession);
      updateSessionBadge(DA.currentSession.repo_name);
    } catch (e) {}
  }
});

// ── Theme Management ─────────────────────────────────────────
function initTheme() {
  const saved = localStorage.getItem('da_theme') || 'light';
  applyTheme(saved);
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  const icon = document.getElementById('themeIcon');
  if (icon) {
    icon.className = theme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
  }
  // Update highlight.js theme
  const lightHljs = document.getElementById('hljs-theme-light');
  const darkHljs = document.getElementById('hljs-theme-dark');
  if (lightHljs) lightHljs.disabled = theme === 'dark';
  if (darkHljs) darkHljs.disabled = theme === 'light';

  // Update Mermaid theme
  if (DA.mermaidInitialized) {
    const mermaidTheme = theme === 'dark' ? 'dark' : 'default';
    mermaid.initialize({ startOnLoad: false, theme: mermaidTheme });
  }
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  localStorage.setItem('da_theme', next);
  applyTheme(next);
}

// ── Mermaid Init ─────────────────────────────────────────────
function initMermaid() {
  try {
    const theme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'default';
    mermaid.initialize({
      startOnLoad: false,
      theme,
      flowchart: { useMaxWidth: true, htmlLabels: true },
      securityLevel: 'loose',
    });
    DA.mermaidInitialized = true;
  } catch (e) {
    console.warn('Mermaid init failed:', e);
  }
}

async function renderMermaid(containerId, definition) {
  const container = document.getElementById(containerId);
  if (!container || !definition) return;
  try {
    const { svg } = await mermaid.render('mermaid-' + Date.now(), definition);
    container.innerHTML = svg;
  } catch (e) {
    container.innerHTML = `<pre class="text-muted p-3">${escapeHtml(definition)}</pre>`;
  }
}

// ── watsonx.ai Status ────────────────────────────────────────
async function checkWatsonxStatus() {
  const dot = document.getElementById('watsonxDot');
  const status = document.getElementById('watsonxStatus');
  if (!dot || !status) return;

  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    if (data.watsonx_ready) {
      dot.className = 'badge-dot online';
      status.textContent = 'IBM Granite Connected';
    } else {
      dot.className = 'badge-dot offline';
      status.textContent = 'Configure API Key';
    }
  } catch (e) {
    dot.className = 'badge-dot offline';
    status.textContent = 'Offline';
  }
}

// ── Session Management ───────────────────────────────────────
async function loadSessionHistory() {
  try {
    const res = await fetch('/api/sessions');
    const data = await res.json();
    DA.sessions = data.sessions || [];
    renderSessionNav(DA.sessions);
  } catch (e) {}
}

function renderSessionNav(sessions) {
  const container = document.getElementById('session-list-nav');
  if (!container) return;
  if (!sessions.length) {
    container.innerHTML = '<div class="text-muted-sm px-2 py-1" style="font-size:12px;color:#484f58;">No sessions yet</div>';
    return;
  }
  container.innerHTML = sessions.slice(0, 5).map(s => `
    <a class="nav-item" onclick="loadSession('${s.id}')" style="cursor:pointer;">
      <i class="bi bi-${s.repo_type === 'github' ? 'github' : 'file-earmark-zip'}"></i>
      <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(s.repo_name || 'Project')}</span>
    </a>
  `).join('');
}

async function loadSession(sessionId) {
  try {
    const res = await fetch(`/api/sessions/${sessionId}`);
    const data = await res.json();
    DA.currentSession = data;
    localStorage.setItem('da_last_session', JSON.stringify(data));
    updateSessionBadge(data.repo_name);
    if (window.location.pathname !== '/dashboard') {
      window.location.href = '/dashboard';
    } else if (window.loadDashboardForSession) {
      window.loadDashboardForSession(sessionId);
    }
  } catch (e) {
    showToast('Failed to load session', 'error');
  }
}

function updateSessionBadge(name) {
  const badge = document.getElementById('currentSessionBadge');
  const nameEl = document.getElementById('currentSessionName');
  if (badge && nameEl && name) {
    nameEl.textContent = name;
    badge.style.display = 'flex';
  }
}

// ── ZIP Upload ───────────────────────────────────────────────
let selectedFile = null;

function handleDrop(event) {
  event.preventDefault();
  event.currentTarget.classList.remove('drag-over');
  const file = event.dataTransfer.files[0];
  if (file && file.name.endsWith('.zip')) {
    selectFile(file);
  } else {
    showToast('Please drop a valid .zip file', 'warning');
  }
}

function handleFileSelect(event) {
  const file = event.target.files[0];
  if (file) selectFile(file);
}

function selectFile(file) {
  if (file.size > 100 * 1024 * 1024) {
    showToast('File too large. Maximum 100 MB.', 'error');
    return;
  }
  selectedFile = file;
  document.getElementById('selectedFileName').textContent = file.name;
  document.getElementById('fileSelected').classList.remove('d-none');
  document.getElementById('dropZone').style.display = 'none';
  document.getElementById('uploadBtn').disabled = false;
}

function clearFile() {
  selectedFile = null;
  document.getElementById('fileInput').value = '';
  document.getElementById('fileSelected').classList.add('d-none');
  document.getElementById('dropZone').style.display = '';
  document.getElementById('uploadBtn').disabled = true;
}

async function uploadZip() {
  if (!selectedFile) return;
  const btn = document.getElementById('uploadBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Uploading...';

  showAnalysisModal('Uploading Repository', 'Extracting and parsing files...');

  try {
    const formData = new FormData();
    formData.append('file', selectedFile);

    const res = await fetch('/api/repo/upload', { method: 'POST', body: formData });
    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || 'Upload failed');
    }

    DA.currentSession = data;
    localStorage.setItem('da_last_session', JSON.stringify(data));
    updateSessionBadge(data.repo_name);
    loadSessionHistory();

    showToast(`Repository "${data.repo_name}" uploaded successfully!`, 'success');
    hideAnalysisModal();

    // Redirect to dashboard
    setTimeout(() => { window.location.href = '/dashboard'; }, 800);
  } catch (e) {
    hideAnalysisModal();
    showToast(e.message || 'Upload failed', 'error');
    btn.disabled = false;
    btn.innerHTML = '<i class="bi bi-upload me-2"></i>Upload & Analyze';
  }
}

// ── GitHub Import ────────────────────────────────────────────
async function importGithub() {
  const url = document.getElementById('githubUrl').value.trim();
  if (!url) return;

  const btn = document.getElementById('importBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Importing...';

  showAnalysisModal('Importing GitHub Repository', 'Downloading repository from GitHub...');
  setProgress(20);

  try {
    const res = await fetch('/api/repo/github', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    const data = await res.json();

    if (!res.ok) throw new Error(data.error || 'Import failed');

    setProgress(80);
    DA.currentSession = data;
    localStorage.setItem('da_last_session', JSON.stringify(data));
    updateSessionBadge(data.repo_name);
    loadSessionHistory();

    showToast(`Repository "${data.repo_name}" imported successfully!`, 'success');
    setProgress(100);
    setTimeout(() => {
      hideAnalysisModal();
      window.location.href = '/dashboard';
    }, 600);
  } catch (e) {
    hideAnalysisModal();
    showToast(e.message || 'Import failed', 'error');
    btn.disabled = false;
    btn.innerHTML = '<i class="bi bi-github me-2"></i>Import & Analyze';
  }
}

// ── Agent Navigation ─────────────────────────────────────────
function navigateTo(tab) {
  if (window.location.pathname !== '/dashboard') {
    sessionStorage.setItem('da_target_tab', tab);
    window.location.href = '/dashboard';
    return;
  }
  if (window.switchTab) switchTab(tab);
  if (window.runAgent && DA.currentSession) runAgent(tab);
}

function generateReport() {
  if (!DA.currentSession) {
    showToast('Please upload and analyze a repository first.', 'warning');
    return;
  }
  if (window.location.pathname !== '/dashboard') {
    window.location.href = '/dashboard';
    return;
  }
  if (window.generateDashboardReport) generateDashboardReport();
}

// ── Analysis Modal ───────────────────────────────────────────
let analysisModal = null;

function showAnalysisModal(title, text) {
  const el = document.getElementById('analysisModal');
  if (!el) return;
  document.getElementById('analysisModalTitle').textContent = title || 'Processing...';
  document.getElementById('analysisModalText').textContent = text || '';
  setProgress(5);
  if (!analysisModal) analysisModal = new bootstrap.Modal(el, { backdrop: 'static' });
  analysisModal.show();
}

function hideAnalysisModal() {
  if (analysisModal) analysisModal.hide();
}

function setProgress(pct) {
  const bar = document.getElementById('analysisProgress');
  if (bar) bar.style.width = pct + '%';
}

// ── Sidebar ──────────────────────────────────────────────────
function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebarOverlay');
  sidebar.classList.toggle('open');
  overlay.classList.toggle('show');
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('show');
}

// ── Toast Notifications ──────────────────────────────────────
function showToast(message, type = 'info', duration = 4000) {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const icons = { success: 'bi-check-circle-fill', error: 'bi-x-circle-fill', warning: 'bi-exclamation-triangle-fill', info: 'bi-info-circle-fill' };
  const colors = { success: '#2ea043', error: '#da3633', warning: '#d29922', info: '#2188ff' };

  const id = 'toast-' + Date.now();
  const html = `
    <div id="${id}" class="toast toast-${type} align-items-center" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="true" data-bs-delay="${duration}">
      <div class="d-flex">
        <div class="toast-body d-flex align-items-center gap-2">
          <i class="bi ${icons[type] || icons.info}" style="color:${colors[type]};"></i>
          ${escapeHtml(message)}
        </div>
        <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    </div>`;
  container.insertAdjacentHTML('beforeend', html);
  const toastEl = document.getElementById(id);
  new bootstrap.Toast(toastEl).show();
  toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
}

// ── API Helper ───────────────────────────────────────────────
async function apiPost(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

// ── Markdown Renderer ────────────────────────────────────────
function renderMarkdown(text) {
  if (!text) return '';
  // Basic Markdown → HTML conversion
  let html = escapeHtml(text);

  // Code blocks
  html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
    `<pre><code class="language-${lang || 'text'}">${code.trim()}</code></pre>`);

  // Inline code
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

  // Headers
  html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');

  // Bold & italic
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');

  // Unordered lists
  html = html.replace(/^[*-] (.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>[\s\S]*?<\/li>\n?)+/g, '<ul>$&</ul>');

  // Numbered lists
  html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>');

  // Blockquote
  html = html.replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>');

  // Horizontal rule
  html = html.replace(/^---+$/gm, '<hr>');

  // Paragraphs (double newlines)
  html = html.replace(/\n\n/g, '</p><p>');
  html = '<p>' + html + '</p>';

  // Clean up empty paragraphs around block elements
  html = html.replace(/<p>(<(?:h[1-6]|ul|ol|pre|hr|blockquote))/g, '$1');
  html = html.replace(/(<\/(?:h[1-6]|ul|ol|pre|hr|blockquote)>)<\/p>/g, '$1');

  return html;
}

// ── Highlight.js ─────────────────────────────────────────────
function highlightAllCode() {
  document.querySelectorAll('pre code').forEach(block => {
    try { hljs.highlightElement(block); } catch(e) {}
  });
}

// ── Utilities ────────────────────────────────────────────────
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function formatNumber(n) {
  if (n === undefined || n === null) return '—';
  return n.toLocaleString();
}

function getGradeColor(grade) {
  return { A: '#2ea043', B: '#3fb950', C: '#d29922', D: '#fd8c73', F: '#da3633' }[grade] || '#8b949e';
}

function getScoreClass(score) {
  if (score >= 90) return 'score-a';
  if (score >= 80) return 'score-b';
  if (score >= 70) return 'score-c';
  if (score >= 60) return 'score-d';
  return 'score-f';
}

function severityClass(severity) {
  const map = { Critical: 'sev-critical', High: 'sev-high', Medium: 'sev-medium', Low: 'sev-low', Informational: 'sev-info', Info: 'sev-info' };
  return map[severity] || 'sev-info';
}

function severityBorderClass(severity) {
  const map = { Critical: 'critical', High: 'high', Medium: 'medium', Low: 'low', Informational: 'info', Info: 'info' };
  return map[severity] || 'info';
}

function getCurrentSessionId() {
  return DA.currentSession?.session_id || DA.currentSession?.id || null;
}

function timeAgo(dateStr) {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

// ── Language Colors ──────────────────────────────────────────
const LANG_COLORS = {
  Python: '#3776AB', JavaScript: '#F7DF1E', TypeScript: '#3178C6',
  Java: '#ED8B00', Go: '#00ADD8', Ruby: '#CC342D', PHP: '#777BB4',
  'C#': '#239120', 'C++': '#00599C', C: '#555555', Rust: '#CE422B',
  Kotlin: '#7F52FF', Swift: '#FA7343', HTML: '#E34F26', CSS: '#1572B6',
  SCSS: '#CC6699', SQL: '#4479A1', 'Vue.js': '#42B883', 'React JSX': '#61DAFB',
  Go: '#00ADD8', Shell: '#89E051', Markdown: '#083FA1',
  YAML: '#CB171E', JSON: '#292929', Dockerfile: '#2496ED',
};

function getLangColor(lang) {
  return LANG_COLORS[lang] || '#8b949e';
}
