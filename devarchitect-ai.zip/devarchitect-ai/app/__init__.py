"""
DevArchitect AI - Flask Application Factory
"""
import os
import logging
from flask import Flask
from flask_cors import CORS
from dotenv import load_dotenv
from app.config import Config
from app.utils.logger import setup_logger

load_dotenv()


def create_app(config_class=Config):
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_object(config_class)

    CORS(app, resources={r"/api/*": {"origins": "*"}})

    setup_logger(app)

    # Ensure required directories exist
    for folder in [
        app.config["UPLOAD_FOLDER"],
        app.config["REPOS_FOLDER"],
        app.config["REPORTS_FOLDER"],
        app.config["VECTOR_STORE_FOLDER"],
        "logs",
    ]:
        os.makedirs(folder, exist_ok=True)

    # Register blueprints
    from app.blueprints.main import main_bp
    from app.blueprints.api import api_bp
    from app.blueprints.agents import agents_bp
    from app.blueprints.repo import repo_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp, url_prefix="/api")
    app.register_blueprint(agents_bp, url_prefix="/api/agents")
    app.register_blueprint(repo_bp, url_prefix="/api/repo")

    app.logger.info("DevArchitect AI started successfully.")
    return app
