"""
DevArchitect AI - PDF Report Generation Service
"""
import os
import io
import logging
from datetime import datetime
from typing import Dict, List
from flask import current_app

logger = logging.getLogger(__name__)

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib import colors
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        HRFlowable, PageBreak,
    )
    from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False
    logger.warning("reportlab not available. PDF generation will produce Markdown fallback.")


def generate_pdf_report(session_id: str, analysis_data: Dict) -> str:
    """Generate a PDF report for the given analysis data. Returns file path."""
    reports_folder = current_app.config["REPORTS_FOLDER"]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = os.path.join(reports_folder, f"devarchitect_report_{session_id[:8]}_{timestamp}.pdf")

    if not REPORTLAB_AVAILABLE:
        # Fallback to Markdown
        md_path = report_path.replace(".pdf", ".md")
        content = generate_markdown_report(analysis_data)
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(content)
        return md_path

    try:
        doc = SimpleDocTemplate(
            report_path,
            pagesize=A4,
            rightMargin=0.75 * inch,
            leftMargin=0.75 * inch,
            topMargin=1 * inch,
            bottomMargin=0.75 * inch,
        )

        styles = getSampleStyleSheet()
        story = []

        # Custom styles
        title_style = ParagraphStyle(
            "Title",
            parent=styles["Heading1"],
            fontSize=24,
            spaceAfter=6,
            textColor=colors.HexColor("#1e3a5f"),
            alignment=TA_CENTER,
        )
        subtitle_style = ParagraphStyle(
            "Subtitle",
            parent=styles["Normal"],
            fontSize=12,
            spaceAfter=20,
            textColor=colors.HexColor("#666666"),
            alignment=TA_CENTER,
        )
        section_style = ParagraphStyle(
            "SectionHead",
            parent=styles["Heading2"],
            fontSize=14,
            textColor=colors.HexColor("#1e3a5f"),
            spaceBefore=16,
            spaceAfter=6,
        )
        body_style = ParagraphStyle(
            "Body",
            parent=styles["Normal"],
            fontSize=10,
            leading=14,
            spaceAfter=4,
        )
        code_style = ParagraphStyle(
            "Code",
            parent=styles["Normal"],
            fontSize=8,
            fontName="Courier",
            backColor=colors.HexColor("#f5f5f5"),
            leftIndent=12,
            rightIndent=12,
            spaceAfter=6,
            spaceBefore=6,
        )

        # Cover Page
        story.append(Spacer(1, 0.5 * inch))
        story.append(Paragraph("🔷 DevArchitect AI", title_style))
        story.append(Paragraph("Multi-Agent Software Engineering Analysis Report", subtitle_style))
        story.append(Paragraph(f"Generated: {datetime.now().strftime('%B %d, %Y at %H:%M UTC')}", subtitle_style))
        story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#3b82d4")))
        story.append(Spacer(1, 0.3 * inch))

        # Executive Summary
        repo_data = analysis_data.get("repository", {})
        health = repo_data.get("health_score", {})

        summary_table_data = [
            ["Metric", "Value"],
            ["Total Files", str(repo_data.get("total_files", "N/A"))],
            ["Total Lines", str(repo_data.get("total_lines", "N/A"))],
            ["Primary Language", str(repo_data.get("primary_language", "N/A"))],
            ["Frameworks", ", ".join(repo_data.get("frameworks", [])[:3]) or "None"],
            ["Health Score", f"{health.get('overall', 0)}/100 ({health.get('grade', 'N/A')})"],
            ["License", str(repo_data.get("license", "N/A"))],
        ]

        summary_table = Table(summary_table_data, colWidths=[2.5 * inch, 4 * inch])
        summary_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e3a5f")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, 0), 10),
            ("FONTSIZE", (0, 1), (-1, -1), 9),
            ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor("#f8f9fa")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f4f8")]),
            ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#d0d0d0")),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e0e0e0")),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ]))

        story.append(Paragraph("Executive Summary", section_style))
        story.append(summary_table)
        story.append(Spacer(1, 0.2 * inch))

        ai_summary = repo_data.get("ai_summary", "")
        if ai_summary:
            story.append(Paragraph("AI Analysis Summary", section_style))
            clean_summary = ai_summary[:2000].replace("**", "").replace("#", "").replace("`", "")
            story.append(Paragraph(clean_summary, body_style))

        # Language Distribution
        lang_dist = repo_data.get("language_distribution", [])
        if lang_dist:
            story.append(PageBreak())
            story.append(Paragraph("Language Distribution", section_style))
            lang_data = [["Language", "Code Lines", "Percentage"]]
            for l in lang_dist[:10]:
                lang_data.append([l["language"], str(l["lines"]), f"{l['percentage']}%"])
            lang_table = Table(lang_data, colWidths=[2.5 * inch, 2 * inch, 2 * inch])
            lang_table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#3b82d4")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f4f8")]),
                ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#d0d0d0")),
                ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e0e0e0")),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]))
            story.append(lang_table)

        # Security Analysis
        security_data = analysis_data.get("security", {})
        if security_data:
            story.append(PageBreak())
            story.append(Paragraph("Security Analysis", section_style))
            risk = security_data.get("risk_score", {})
            story.append(Paragraph(
                f"Security Score: {risk.get('score', 0)}/100 | Grade: {risk.get('grade', 'N/A')} | "
                f"Risk Level: {risk.get('risk_level', 'N/A')}",
                body_style
            ))

            findings = security_data.get("findings", [])[:15]
            if findings:
                sec_data = [["Severity", "Type", "File", "Line"]]
                for f in findings:
                    sec_data.append([
                        f.get("severity", ""),
                        f.get("type", "")[:30],
                        os.path.basename(f.get("file", ""))[:25],
                        str(f.get("line", "")),
                    ])
                sec_table = Table(sec_data, colWidths=[1 * inch, 2 * inch, 2.5 * inch, 0.8 * inch])
                sec_table.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#c0392b")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, -1), 8),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#fff0f0")]),
                    ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#d0d0d0")),
                    ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e0e0e0")),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]))
                story.append(sec_table)

        # Code Quality
        code_data = analysis_data.get("code_review", {})
        if code_data:
            story.append(PageBreak())
            story.append(Paragraph("Code Quality Review", section_style))
            quality = code_data.get("quality_score", {})
            story.append(Paragraph(
                f"Quality Score: {quality.get('score', 0)}/100 | Grade: {quality.get('grade', 'N/A')} | "
                f"Total Issues: {code_data.get('total_issues', 0)}",
                body_style
            ))

        # Footer
        story.append(Spacer(1, 0.5 * inch))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#d0d0d0")))
        story.append(Paragraph(
            f"DevArchitect AI — IBM watsonx.ai Granite Powered | Report ID: {session_id[:8]} | {datetime.now().strftime('%Y-%m-%d')}",
            ParagraphStyle("Footer", parent=styles["Normal"], fontSize=8, textColor=colors.grey, alignment=TA_CENTER)
        ))

        doc.build(story)
        logger.info(f"PDF report generated: {report_path}")
        return report_path

    except Exception as e:
        logger.error(f"PDF generation failed: {e}")
        # Fallback to markdown
        md_path = report_path.replace(".pdf", ".md")
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(generate_markdown_report(analysis_data))
        return md_path


def generate_markdown_report(analysis_data: Dict) -> str:
    """Generate a Markdown report as fallback."""
    repo_data = analysis_data.get("repository", {})
    security = analysis_data.get("security", {})
    code_review = analysis_data.get("code_review", {})
    health = repo_data.get("health_score", {})

    lines = [
        "# DevArchitect AI — Analysis Report",
        f"*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M UTC')}*",
        "",
        "---",
        "",
        "## Executive Summary",
        "",
        f"| Metric | Value |",
        f"|--------|-------|",
        f"| Total Files | {repo_data.get('total_files', 'N/A')} |",
        f"| Total Lines | {repo_data.get('total_lines', 'N/A')} |",
        f"| Primary Language | {repo_data.get('primary_language', 'N/A')} |",
        f"| Frameworks | {', '.join(repo_data.get('frameworks', [])[:5]) or 'None'} |",
        f"| Health Score | {health.get('overall', 0)}/100 ({health.get('grade', 'N/A')}) |",
        f"| License | {repo_data.get('license', 'N/A')} |",
        "",
        "## AI Summary",
        "",
        repo_data.get("ai_summary", "No summary available."),
        "",
        "## Security Analysis",
        "",
        f"**Risk Score:** {security.get('risk_score', {}).get('score', 0)}/100",
        f"**Total Findings:** {security.get('total_findings', 0)}",
        "",
    ]

    for finding in security.get("findings", [])[:10]:
        lines.append(f"- [{finding['severity']}] **{finding['type']}** — `{finding['file']}:{finding['line']}`")
        lines.append(f"  - {finding.get('remediation', '')}")

    lines += [
        "",
        "## Code Quality",
        "",
        f"**Quality Score:** {code_review.get('quality_score', {}).get('score', 0)}/100",
        f"**Total Issues:** {code_review.get('total_issues', 0)}",
        "",
        "---",
        "*DevArchitect AI — Powered by IBM watsonx.ai Granite*",
    ]

    return "\n".join(lines)
