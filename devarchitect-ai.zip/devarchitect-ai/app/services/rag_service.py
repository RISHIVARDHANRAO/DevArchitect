"""
DevArchitect AI - RAG Service (FAISS-backed Vector Store)
"""
import os
import json
import logging
import hashlib
import pickle
from typing import Dict, List, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    import faiss
    import numpy as np
    from sentence_transformers import SentenceTransformer
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False
    logger.warning("FAISS or sentence-transformers not available. RAG search will use keyword fallback.")


class RAGService:
    """
    Retrieval-Augmented Generation service using FAISS vector store
    and sentence-transformers for embedding repository files.
    """

    def __init__(self, vector_store_path: str, embedding_model: str = "all-MiniLM-L6-v2"):
        self.vector_store_path = vector_store_path
        self.embedding_model_name = embedding_model
        self._model = None
        self._indexes: Dict[str, Dict] = {}  # session_id → {index, chunks, metadata}
        os.makedirs(vector_store_path, exist_ok=True)

    @property
    def model(self):
        if self._model is None and FAISS_AVAILABLE:
            try:
                logger.info(f"Loading embedding model: {self.embedding_model_name}")
                self._model = SentenceTransformer(self.embedding_model_name)
                logger.info("Embedding model loaded successfully.")
            except Exception as e:
                logger.error(f"Failed to load embedding model: {e}")
        return self._model

    def index_repository(self, session_id: str, contents: Dict[str, str],
                          chunk_size: int = 1000, overlap: int = 200) -> bool:
        """
        Chunk repository files and build a FAISS index.
        Persists the index to disk for the session.
        """
        chunks = []
        metadata = []

        for filepath, content in contents.items():
            if not content or len(content.strip()) < 50:
                continue
            file_chunks = self._chunk_text(content, filepath, chunk_size, overlap)
            chunks.extend(file_chunks)
            metadata.extend([{"source": filepath}] * len(file_chunks))

        if not chunks:
            logger.warning(f"No chunks to index for session {session_id}")
            return False

        logger.info(f"Indexing {len(chunks)} chunks for session {session_id}")

        if FAISS_AVAILABLE and self.model:
            try:
                embeddings = self.model.encode(
                    [c["content"] for c in chunks],
                    batch_size=64,
                    show_progress_bar=False,
                    normalize_embeddings=True,
                )
                embeddings = np.array(embeddings, dtype="float32")

                index = faiss.IndexFlatIP(embeddings.shape[1])  # Inner product (cosine)
                index.add(embeddings)

                self._indexes[session_id] = {
                    "index": index,
                    "chunks": chunks,
                    "metadata": metadata,
                    "chunk_count": len(chunks),
                }

                # Persist to disk
                self._persist_index(session_id)
                logger.info(f"FAISS index built: {len(chunks)} chunks")
                return True
            except Exception as e:
                logger.error(f"FAISS indexing error: {e}")

        # Keyword fallback
        self._indexes[session_id] = {
            "index": None,
            "chunks": chunks,
            "metadata": metadata,
            "chunk_count": len(chunks),
        }
        return True

    def search(self, query: str, session_id: str, k: int = 5) -> List[Dict]:
        """Search indexed repository for relevant chunks."""
        if not self.has_index(session_id):
            # Try to load from disk
            if not self._load_index(session_id):
                return []

        data = self._indexes.get(session_id, {})
        chunks = data.get("chunks", [])
        index = data.get("index")

        if not chunks:
            return []

        # FAISS vector search
        if index is not None and FAISS_AVAILABLE and self.model:
            try:
                query_embedding = self.model.encode(
                    [query], normalize_embeddings=True
                ).astype("float32")
                scores, indices = index.search(query_embedding, min(k, len(chunks)))

                results = []
                for score, idx in zip(scores[0], indices[0]):
                    if idx < 0 or idx >= len(chunks):
                        continue
                    chunk = chunks[idx]
                    results.append({
                        "content": chunk["content"],
                        "source": chunk["source"],
                        "start_line": chunk.get("start_line", 0),
                        "end_line": chunk.get("end_line", 0),
                        "score": float(score),
                    })
                return results
            except Exception as e:
                logger.error(f"FAISS search error: {e}")

        # Keyword fallback
        return self._keyword_search(query, chunks, k)

    def _keyword_search(self, query: str, chunks: List[Dict], k: int) -> List[Dict]:
        """Simple keyword-based fallback search."""
        query_lower = query.lower()
        query_terms = [t for t in query_lower.split() if len(t) > 2]

        scored = []
        for chunk in chunks:
            content_lower = chunk["content"].lower()
            score = sum(content_lower.count(term) for term in query_terms)
            if score > 0:
                scored.append((score, chunk))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [
            {
                "content": c["content"],
                "source": c["source"],
                "start_line": c.get("start_line", 0),
                "end_line": c.get("end_line", 0),
                "score": s,
            }
            for s, c in scored[:k]
        ]

    def _chunk_text(self, content: str, filepath: str,
                    chunk_size: int, overlap: int) -> List[Dict]:
        """Split file content into overlapping chunks."""
        lines = content.splitlines()
        chunks = []
        current_chunk = []
        current_size = 0
        start_line = 1

        for i, line in enumerate(lines, 1):
            current_chunk.append(line)
            current_size += len(line) + 1

            if current_size >= chunk_size:
                chunk_text = "\n".join(current_chunk)
                chunks.append({
                    "content": chunk_text,
                    "source": filepath,
                    "start_line": start_line,
                    "end_line": i,
                })
                # Overlap: keep last N characters worth of lines
                overlap_lines = []
                overlap_size = 0
                for l in reversed(current_chunk):
                    if overlap_size >= overlap:
                        break
                    overlap_lines.insert(0, l)
                    overlap_size += len(l) + 1
                current_chunk = overlap_lines
                current_size = overlap_size
                start_line = i - len(overlap_lines) + 1

        if current_chunk:
            chunks.append({
                "content": "\n".join(current_chunk),
                "source": filepath,
                "start_line": start_line,
                "end_line": len(lines),
            })
        return chunks

    def has_index(self, session_id: str) -> bool:
        return session_id in self._indexes

    def _persist_index(self, session_id: str):
        """Persist index to disk."""
        try:
            session_dir = os.path.join(self.vector_store_path, session_id)
            os.makedirs(session_dir, exist_ok=True)

            data = self._indexes[session_id]
            # Save chunks and metadata (not the FAISS index object — save separately)
            with open(os.path.join(session_dir, "chunks.pkl"), "wb") as f:
                pickle.dump({"chunks": data["chunks"], "metadata": data["metadata"]}, f)

            if data.get("index") is not None and FAISS_AVAILABLE:
                faiss.write_index(data["index"], os.path.join(session_dir, "index.faiss"))
        except Exception as e:
            logger.error(f"Failed to persist index: {e}")

    def _load_index(self, session_id: str) -> bool:
        """Load index from disk."""
        try:
            session_dir = os.path.join(self.vector_store_path, session_id)
            chunks_path = os.path.join(session_dir, "chunks.pkl")
            if not os.path.exists(chunks_path):
                return False

            with open(chunks_path, "rb") as f:
                data = pickle.load(f)

            index = None
            if FAISS_AVAILABLE:
                faiss_path = os.path.join(session_dir, "index.faiss")
                if os.path.exists(faiss_path):
                    index = faiss.read_index(faiss_path)

            self._indexes[session_id] = {
                "index": index,
                "chunks": data["chunks"],
                "metadata": data["metadata"],
                "chunk_count": len(data["chunks"]),
            }
            return True
        except Exception as e:
            logger.error(f"Failed to load index: {e}")
            return False

    def clear_session(self, session_id: str):
        """Remove index for a session."""
        import shutil
        if session_id in self._indexes:
            del self._indexes[session_id]
        session_dir = os.path.join(self.vector_store_path, session_id)
        if os.path.exists(session_dir):
            shutil.rmtree(session_dir, ignore_errors=True)

    def get_stats(self, session_id: str) -> Dict:
        if not self.has_index(session_id):
            return {"indexed": False}
        data = self._indexes.get(session_id, {})
        return {
            "indexed": True,
            "chunk_count": data.get("chunk_count", 0),
            "faiss_enabled": data.get("index") is not None,
        }
