"""
DevArchitect AI - Session & Repository State Manager
"""
import os
import json
import uuid
import shutil
import logging
from datetime import datetime
from typing import Dict, Optional
from flask import current_app

logger = logging.getLogger(__name__)

# In-memory session store (for production, use Redis)
_sessions: Dict[str, Dict] = {}


def create_session() -> str:
    """Create a new analysis session."""
    session_id = str(uuid.uuid4())
    _sessions[session_id] = {
        "id": session_id,
        "created_at": datetime.utcnow().isoformat(),
        "status": "created",
        "repo_path": None,
        "repo_name": None,
        "repo_type": None,  # "zip" or "github"
        "analysis": {},
        "chat_history": [],
    }
    return session_id


def get_session(session_id: str) -> Optional[Dict]:
    return _sessions.get(session_id)


def update_session(session_id: str, **kwargs):
    if session_id in _sessions:
        _sessions[session_id].update(kwargs)


def set_analysis(session_id: str, key: str, data: dict):
    if session_id in _sessions:
        _sessions[session_id]["analysis"][key] = data


def get_analysis(session_id: str, key: str) -> Optional[dict]:
    session = _sessions.get(session_id)
    if session:
        return session["analysis"].get(key)
    return None


def add_chat_message(session_id: str, role: str, content: str):
    if session_id in _sessions:
        _sessions[session_id]["chat_history"].append({
            "role": role,
            "content": content,
            "timestamp": datetime.utcnow().isoformat(),
        })


def get_chat_history(session_id: str) -> list:
    session = _sessions.get(session_id)
    return session.get("chat_history", []) if session else []


def list_sessions() -> list:
    return [
        {
            "id": s["id"],
            "repo_name": s.get("repo_name", "Unknown"),
            "repo_type": s.get("repo_type", ""),
            "status": s.get("status", ""),
            "created_at": s.get("created_at", ""),
            "has_analysis": bool(s.get("analysis")),
        }
        for s in sorted(_sessions.values(), key=lambda x: x.get("created_at", ""), reverse=True)
    ]


def delete_session(session_id: str):
    if session_id in _sessions:
        repo_path = _sessions[session_id].get("repo_path")
        if repo_path and os.path.exists(os.path.dirname(repo_path)):
            shutil.rmtree(os.path.dirname(repo_path), ignore_errors=True)
        del _sessions[session_id]
