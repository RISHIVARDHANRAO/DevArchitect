"""
DevArchitect AI - Repository Parsing Utilities
"""
import os
import re
import ast
import json
import chardet
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# ── Language detection maps ──────────────────────────────────────────────────
EXTENSION_LANGUAGE_MAP = {
    ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript",
    ".jsx": "React JSX", ".tsx": "React TSX", ".java": "Java",
    ".go": "Go", ".rb": "Ruby", ".php": "PHP", ".cs": "C#",
    ".cpp": "C++", ".c": "C", ".h": "C/C++ Header", ".rs": "Rust",
    ".kt": "Kotlin", ".swift": "Swift", ".vue": "Vue.js",
    ".html": "HTML", ".css": "CSS", ".scss": "SCSS/Sass",
    ".sql": "SQL", ".yaml": "YAML", ".yml": "YAML",
    ".json": "JSON", ".toml": "TOML", ".xml": "XML",
    ".md": "Markdown", ".sh": "Shell", ".bash": "Bash",
    ".dockerfile": "Dockerfile", ".tf": "Terraform", ".r": "R",
    ".scala": "Scala", ".ex": "Elixir", ".exs": "Elixir",
    ".clj": "Clojure", ".hs": "Haskell", ".lua": "Lua",
    ".dart": "Dart", ".fs": "F#", ".elm": "Elm",
}

FRAMEWORK_SIGNATURES = {
    "Django": ["django", "DJANGO_SETTINGS_MODULE", "urls.py", "wsgi.py", "asgi.py"],
    "FastAPI": ["fastapi", "uvicorn", "@app.get", "@app.post"],
    "Flask": ["from flask", "import flask", "Flask(__name__)"],
    "React": ["react", "ReactDOM", "useState", "useEffect", "jsx"],
    "Vue.js": ["vue", "<template>", "createApp", "defineComponent"],
    "Angular": ["@angular", "@NgModule", "@Component", "angular.json"],
    "Next.js": ["next", "getServerSideProps", "getStaticProps", "_app.js"],
    "Express": ["express()", "app.listen", "require('express')"],
    "Spring Boot": ["@SpringBootApplication", "spring-boot", "@RestController"],
    "Laravel": ["artisan", "Illuminate\\", "App\\Http\\Controllers"],
    "Rails": ["Rails.application", "ActiveRecord", "ApplicationController"],
    "Nest.js": ["@nestjs", "@Module", "@Controller", "@Injectable"],
    "Svelte": [".svelte", "svelte/store", "SvelteComponent"],
    "Nuxt.js": ["nuxt", "nuxt.config", "useNuxtApp"],
    "Tailwind": ["tailwind", "tailwindcss"],
    "Bootstrap": ["bootstrap", "btn-primary", "container-fluid"],
    "Docker": ["Dockerfile", "docker-compose.yml", "FROM ", "EXPOSE "],
    "Kubernetes": ["kind: Deployment", "kind: Service", "kubectl"],
    "GraphQL": ["graphql", "gql`", "GraphQLSchema", "typeDefs"],
    "REST API": ["@app.route", "@router.get", "app.get(", "app.post("],
}

LICENSE_FILES = {"LICENSE", "LICENSE.md", "LICENSE.txt", "COPYING", "COPYING.md"}


def safe_read_file(filepath: str, max_kb: int = 500) -> Optional[str]:
    """Safely read a file with encoding detection."""
    try:
        size_kb = os.path.getsize(filepath) / 1024
        if size_kb > max_kb:
            return None
        with open(filepath, "rb") as f:
            raw = f.read()
        detected = chardet.detect(raw)
        encoding = detected.get("encoding") or "utf-8"
        return raw.decode(encoding, errors="replace")
    except Exception:
        return None


def get_language(filepath: str) -> str:
    """Detect programming language from file extension."""
    ext = Path(filepath).suffix.lower()
    name = Path(filepath).name.lower()
    if name == "dockerfile":
        return "Dockerfile"
    if name in {"makefile", "gnumakefile"}:
        return "Makefile"
    return EXTENSION_LANGUAGE_MAP.get(ext, "Unknown")


def count_lines(content: str) -> Dict[str, int]:
    """Count total, code, comment, and blank lines."""
    lines = content.splitlines()
    total = len(lines)
    blank = sum(1 for l in lines if not l.strip())
    comment = sum(
        1 for l in lines
        if l.strip().startswith(("#", "//", "/*", "*", "<!--", "--", ";"))
    )
    code = total - blank - comment
    return {"total": total, "code": max(code, 0), "comment": comment, "blank": blank}


def extract_python_structure(content: str) -> Dict:
    """Extract classes, functions, imports from Python source."""
    structure = {"classes": [], "functions": [], "imports": [], "global_vars": []}
    try:
        tree = ast.parse(content)
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                methods = [
                    n.name for n in ast.walk(node)
                    if isinstance(n, ast.FunctionDef) and n.col_offset > 0
                ]
                structure["classes"].append({"name": node.name, "line": node.lineno, "methods": methods})
            elif isinstance(node, ast.FunctionDef) and node.col_offset == 0:
                structure["functions"].append({"name": node.name, "line": node.lineno})
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        structure["imports"].append(alias.name)
                else:
                    structure["imports"].append(node.module or "")
    except SyntaxError:
        pass
    return structure


def extract_js_structure(content: str) -> Dict:
    """Extract exports, functions, classes from JS/TS source."""
    structure = {"functions": [], "classes": [], "exports": [], "imports": []}
    func_pattern = re.compile(r"(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\()")
    class_pattern = re.compile(r"class\s+(\w+)")
    import_pattern = re.compile(r"import\s+.+?\s+from\s+['\"](.+?)['\"]")
    export_pattern = re.compile(r"export\s+(?:default\s+)?(?:function|class|const|let|var)?\s*(\w+)")

    for m in func_pattern.finditer(content):
        name = m.group(1) or m.group(2)
        if name:
            structure["functions"].append(name)
    for m in class_pattern.finditer(content):
        structure["classes"].append(m.group(1))
    for m in import_pattern.finditer(content):
        structure["imports"].append(m.group(1))
    for m in export_pattern.finditer(content):
        structure["exports"].append(m.group(1))
    return structure


def detect_frameworks(files: List[str], contents: Dict[str, str]) -> List[str]:
    """Detect frameworks used in the project."""
    detected = set()
    all_content = " ".join(contents.values())
    all_files_lower = [f.lower() for f in files]
    for framework, signatures in FRAMEWORK_SIGNATURES.items():
        for sig in signatures:
            if sig.lower() in all_content.lower() or any(sig.lower() in f for f in all_files_lower):
                detected.add(framework)
                break
    return sorted(detected)


def detect_license(files: List[str], contents: Dict[str, str]) -> str:
    """Detect project license."""
    for filepath, content in contents.items():
        fname = Path(filepath).name.upper()
        if fname in LICENSE_FILES or "LICENSE" in fname:
            content_upper = content.upper()
            if "MIT" in content_upper:
                return "MIT"
            elif "APACHE" in content_upper:
                return "Apache 2.0"
            elif "GNU GENERAL PUBLIC" in content_upper:
                return "GPL"
            elif "BSD" in content_upper:
                return "BSD"
            elif "MOZILLA" in content_upper:
                return "MPL"
            elif "ISC" in content_upper:
                return "ISC"
            return "Custom License"
    return "No License Detected"


def extract_dependencies(contents: Dict[str, str]) -> Dict[str, List[str]]:
    """Extract project dependencies from manifests."""
    deps = {}
    for filepath, content in contents.items():
        name = Path(filepath).name
        try:
            if name == "requirements.txt":
                pkgs = [
                    line.split("==")[0].split(">=")[0].split("<=")[0].strip()
                    for line in content.splitlines()
                    if line.strip() and not line.startswith("#")
                ]
                deps["Python (requirements.txt)"] = pkgs
            elif name == "package.json":
                data = json.loads(content)
                all_deps = list(data.get("dependencies", {}).keys()) + \
                           list(data.get("devDependencies", {}).keys())
                deps["Node.js (package.json)"] = all_deps
            elif name in ("Pipfile", "pyproject.toml"):
                deps[f"Python ({name})"] = re.findall(r'^\s*"?([a-zA-Z0-9_\-]+)"?\s*=', content, re.M)
            elif name == "pom.xml":
                deps["Java (Maven)"] = re.findall(r"<artifactId>([^<]+)</artifactId>", content)
            elif name == "build.gradle":
                deps["Java (Gradle)"] = re.findall(r'(?:implementation|compile)\s+["\']([^:]+):[^"\']+["\']', content)
            elif name == "Gemfile":
                deps["Ruby (Gemfile)"] = re.findall(r"gem\s+['\"]([^'\"]+)['\"]", content)
            elif name == "Cargo.toml":
                deps["Rust (Cargo)"] = re.findall(r'^\s*([a-zA-Z0-9_\-]+)\s*=', content, re.M)
            elif name == "go.mod":
                deps["Go (go.mod)"] = re.findall(r"^\s*([a-zA-Z0-9./\-]+)\s+v", content, re.M)
        except Exception:
            continue
    return deps


def calculate_complexity(content: str, language: str) -> int:
    """Rough cyclomatic complexity estimate."""
    decision_keywords = {
        "Python": [r"\bif\b", r"\belif\b", r"\bfor\b", r"\bwhile\b", r"\band\b", r"\bor\b", r"\bexcept\b"],
        "JavaScript": [r"\bif\b", r"\belse if\b", r"\bfor\b", r"\bwhile\b", r"\b&&\b", r"\b\|\|\b", r"\bcatch\b"],
        "Java": [r"\bif\b", r"\belse if\b", r"\bfor\b", r"\bwhile\b", r"\b&&\b", r"\b\|\|\b", r"\bcatch\b"],
        "Go": [r"\bif\b", r"\bfor\b", r"\bselect\b", r"\bcase\b"],
    }
    keywords = decision_keywords.get(language, decision_keywords["JavaScript"])
    complexity = 1
    for kw in keywords:
        complexity += len(re.findall(kw, content))
    return min(complexity, 100)


def build_file_tree(root_path: str) -> Dict:
    """Build a hierarchical file tree."""
    tree = {"name": os.path.basename(root_path), "type": "directory", "children": []}
    try:
        entries = sorted(os.scandir(root_path), key=lambda e: (not e.is_dir(), e.name))
        for entry in entries:
            if entry.name.startswith(".") or entry.name in {"__pycache__", "node_modules", ".git", "venv", ".venv"}:
                continue
            if entry.is_dir():
                subtree = build_file_tree(entry.path)
                if subtree:
                    tree["children"].append(subtree)
            else:
                tree["children"].append({
                    "name": entry.name,
                    "type": "file",
                    "language": get_language(entry.name),
                    "size": entry.stat().st_size,
                })
    except PermissionError:
        pass
    return tree


def collect_files(root_path: str, supported_extensions: set, max_kb: int = 500) -> Tuple[List[str], Dict[str, str]]:
    """Walk repo and collect supported text files."""
    files = []
    contents = {}
    skip_dirs = {"__pycache__", "node_modules", ".git", "venv", ".venv", ".tox", "dist", "build", ".next", ".nuxt"}

    for dirpath, dirnames, filenames in os.walk(root_path):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs and not d.startswith(".")]
        for fname in filenames:
            ext = Path(fname).suffix.lower()
            name_lower = fname.lower()
            full_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(full_path, root_path)

            if ext in supported_extensions or name_lower in {"dockerfile", "makefile", "rakefile", "procfile"}:
                content = safe_read_file(full_path, max_kb)
                if content is not None:
                    files.append(rel_path)
                    contents[rel_path] = content
    return files, contents


def detect_api_endpoints(contents: Dict[str, str]) -> List[Dict]:
    """Extract REST API endpoint definitions."""
    endpoints = []
    patterns = [
        (r'@app\.(?:route|get|post|put|delete|patch)\(["\']([^"\']+)["\']', "Flask"),
        (r'@router\.(?:get|post|put|delete|patch)\(["\']([^"\']+)["\']', "FastAPI/Express"),
        (r'app\.(?:get|post|put|delete|patch)\(["\']([^"\']+)["\']', "Express"),
        (r'@RequestMapping\(["\']([^"\']+)["\']', "Spring"),
        (r'Route::(?:get|post|put|delete)\(["\']([^"\']+)["\']', "Laravel"),
    ]
    for filepath, content in contents.items():
        for pattern, framework in patterns:
            for match in re.finditer(pattern, content):
                endpoints.append({
                    "path": match.group(1),
                    "framework": framework,
                    "file": filepath,
                })
    return endpoints
