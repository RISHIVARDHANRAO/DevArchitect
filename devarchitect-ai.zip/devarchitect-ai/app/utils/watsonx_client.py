"""
DevArchitect AI - IBM watsonx.ai Granite Client
"""
import logging
from typing import Optional
from ibm_watsonx_ai import APIClient, Credentials
from ibm_watsonx_ai.foundation_models import ModelInference
from ibm_watsonx_ai.metanames import GenTextParamsMetaNames as GenParams
from flask import current_app

logger = logging.getLogger(__name__)


class WatsonxClient:
    """Singleton wrapper around IBM watsonx.ai Granite models."""

    _instance = None

    def __init__(self):
        self.api_key = None
        self.url = None
        self.project_id = None
        self.client = None
        self.chat_model = None
        self.code_model = None
        self._initialized = False

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def initialize(self, api_key: str, url: str, project_id: str,
                   model_id: str, code_model_id: str):
        """Initialize IBM watsonx.ai client."""
        try:
            self.api_key = api_key
            self.url = url
            self.project_id = project_id

            credentials = Credentials(url=url, api_key=api_key)
            self.client = APIClient(credentials=credentials)

            self.chat_model = ModelInference(
                model_id=model_id,
                api_client=self.client,
                project_id=project_id,
                params={
                    GenParams.MAX_NEW_TOKENS: 4096,
                    GenParams.MIN_NEW_TOKENS: 10,
                    GenParams.TEMPERATURE: 0.2,
                    GenParams.TOP_P: 0.9,
                    GenParams.REPETITION_PENALTY: 1.1,
                },
            )

            self.code_model = ModelInference(
                model_id=code_model_id,
                api_client=self.client,
                project_id=project_id,
                params={
                    GenParams.MAX_NEW_TOKENS: 4096,
                    GenParams.MIN_NEW_TOKENS: 10,
                    GenParams.TEMPERATURE: 0.1,
                    GenParams.TOP_P: 0.95,
                    GenParams.REPETITION_PENALTY: 1.05,
                },
            )

            self._initialized = True
            logger.info("IBM watsonx.ai client initialized successfully.")
            return True, None
        except Exception as e:
            logger.error(f"Failed to initialize watsonx.ai client: {e}")
            return False, str(e)

    def generate(self, prompt: str, use_code_model: bool = False,
                 max_tokens: int = 4096, temperature: float = 0.2) -> str:
        """Generate text using Granite model."""
        if not self._initialized:
            return "⚠️ IBM watsonx.ai not configured. Please check your API credentials."

        try:
            model = self.code_model if use_code_model else self.chat_model
            params = {
                GenParams.MAX_NEW_TOKENS: max_tokens,
                GenParams.TEMPERATURE: temperature,
            }
            response = model.generate_text(prompt=prompt, params=params)
            return response.strip() if response else "No response generated."
        except Exception as e:
            logger.error(f"Generation error: {e}")
            return f"⚠️ Generation failed: {str(e)}"

    def is_ready(self) -> bool:
        return self._initialized


def get_watsonx_client() -> WatsonxClient:
    """Get or create initialized watsonx client from Flask app config."""
    client = WatsonxClient.get_instance()
    if not client.is_ready():
        cfg = current_app.config
        api_key = cfg.get("IBM_API_KEY", "")
        url = cfg.get("IBM_WATSONX_URL", "")
        project_id = cfg.get("IBM_PROJECT_ID", "")
        model_id = cfg.get("GRANITE_MODEL_ID", "ibm/granite-3-8b-instruct")
        code_model_id = cfg.get("GRANITE_CODE_MODEL_ID", "ibm/granite-34b-code-instruct")

        if api_key and url and project_id:
            client.initialize(api_key, url, project_id, model_id, code_model_id)
    return client
