"""
DevArchitect AI - GitHub Cloning & ZIP Extraction Utilities
"""
import os
import re
import shutil
import zipfile
import requests
from pathlib import Path
from typing import Optional, Tuple
from flask import current_app


def validate_github_url(url: str) -> Optional[Tuple[str, str]]:
    """Validate and extract owner/repo from GitHub URL."""
    patterns = [
        r"github\.com[/:]([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+?)(?:\.git)?(?:/.*)?$",
    ]
    for p in patterns:
        m = re.search(p, url)
        if m:
            return m.group(1), m.group(2).rstrip("/")
    return None


def clone_github_repo(github_url: str, session_id: str) -> Tuple[Optional[str], Optional[str]]:
    """Clone a public GitHub repo using Git API (no git required)."""
    parsed = validate_github_url(github_url)
    if not parsed:
        return None, "Invalid GitHub URL format."

    owner, repo = parsed
    repos_folder = current_app.config["REPOS_FOLDER"]
    dest_path = os.path.join(repos_folder, session_id, repo)

    if os.path.exists(dest_path):
        shutil.rmtree(dest_path)
    os.makedirs(dest_path, exist_ok=True)

    try:
        # Use GitHub API to download as ZIP
        zip_url = f"https://api.github.com/repos/{owner}/{repo}/zipball/HEAD"
        headers = {"Accept": "application/vnd.github.v3+json", "User-Agent": "DevArchitect-AI/1.0"}

        token = current_app.config.get("GITHUB_TOKEN", "")
        if token:
            headers["Authorization"] = f"token {token}"

        response = requests.get(zip_url, headers=headers, stream=True, timeout=120)
        if response.status_code == 404:
            return None, f"Repository '{owner}/{repo}' not found or is private."
        if response.status_code == 403:
            return None, "GitHub API rate limit exceeded. Please provide a GitHub token."
        response.raise_for_status()

        zip_path = os.path.join(repos_folder, session_id, f"{repo}.zip")
        with open(zip_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        # Extract
        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(dest_path)

        # Move contents up if GitHub wraps in a subdirectory
        extracted_dirs = [d for d in os.listdir(dest_path) if os.path.isdir(os.path.join(dest_path, d))]
        if len(extracted_dirs) == 1:
            inner = os.path.join(dest_path, extracted_dirs[0])
            for item in os.listdir(inner):
                shutil.move(os.path.join(inner, item), dest_path)
            shutil.rmtree(inner)

        os.remove(zip_path)
        return dest_path, None

    except requests.exceptions.ConnectionError:
        return None, "Network error. Check your internet connection."
    except Exception as e:
        return None, str(e)


def extract_zip_upload(zip_path: str, session_id: str, project_name: str) -> Tuple[Optional[str], Optional[str]]:
    """Extract an uploaded ZIP file to repos folder."""
    repos_folder = current_app.config["REPOS_FOLDER"]
    dest_path = os.path.join(repos_folder, session_id, project_name)

    if os.path.exists(dest_path):
        shutil.rmtree(dest_path)
    os.makedirs(dest_path, exist_ok=True)

    try:
        with zipfile.ZipFile(zip_path, "r") as z:
            # Security: prevent path traversal
            for member in z.namelist():
                member_path = os.path.realpath(os.path.join(dest_path, member))
                if not member_path.startswith(os.path.realpath(dest_path)):
                    return None, "Unsafe ZIP file detected (path traversal attempt)."
            z.extractall(dest_path)

        # Flatten if single root directory
        entries = os.listdir(dest_path)
        if len(entries) == 1 and os.path.isdir(os.path.join(dest_path, entries[0])):
            inner = os.path.join(dest_path, entries[0])
            for item in os.listdir(inner):
                shutil.move(os.path.join(inner, item), dest_path)
            shutil.rmtree(inner)

        return dest_path, None
    except zipfile.BadZipFile:
        return None, "Invalid ZIP file."
    except Exception as e:
        return None, str(e)


def cleanup_session(session_id: str):
    """Remove all files for a session."""
    repos_folder = current_app.config["REPOS_FOLDER"]
    session_path = os.path.join(repos_folder, session_id)
    if os.path.exists(session_path):
        shutil.rmtree(session_path, ignore_errors=True)


def get_repo_metadata(owner: str, repo: str, token: str = "") -> dict:
    """Fetch GitHub repo metadata."""
    url = f"https://api.github.com/repos/{owner}/{repo}"
    headers = {"Accept": "application/vnd.github.v3+json", "User-Agent": "DevArchitect-AI/1.0"}
    if token:
        headers["Authorization"] = f"token {token}"
    try:
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code == 200:
            data = r.json()
            return {
                "name": data.get("name"),
                "description": data.get("description", ""),
                "stars": data.get("stargazers_count", 0),
                "forks": data.get("forks_count", 0),
                "language": data.get("language", "Unknown"),
                "topics": data.get("topics", []),
                "open_issues": data.get("open_issues_count", 0),
                "default_branch": data.get("default_branch", "main"),
                "created_at": data.get("created_at", ""),
                "updated_at": data.get("updated_at", ""),
                "size_kb": data.get("size", 0),
                "url": data.get("html_url", ""),
                "homepage": data.get("homepage", ""),
                "license": (data.get("license") or {}).get("name", "None"),
                "visibility": data.get("visibility", "public"),
            }
    except Exception:
        pass
    return {}
