"""
DevArchitect AI - Application Configuration
"""
import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    # Flask
    SECRET_KEY = os.getenv("SECRET_KEY", "devarchitect-secret-key-change-me")
    FLASK_ENV = os.getenv("FLASK_ENV", "development")
    DEBUG = os.getenv("FLASK_DEBUG", "false").lower() == "true"
    PORT = int(os.getenv("PORT", 5000))

    # IBM watsonx.ai
    IBM_API_KEY = os.getenv("IBM_API_KEY", "")
    IBM_WATSONX_URL = os.getenv("IBM_WATSONX_URL", "https://us-south.ml.cloud.ibm.com")
    IBM_PROJECT_ID = os.getenv("IBM_PROJECT_ID", "")

    # Granite Models
    GRANITE_MODEL_ID = os.getenv("GRANITE_MODEL_ID", "ibm/granite-3-8b-instruct")
    GRANITE_CODE_MODEL_ID = os.getenv("GRANITE_CODE_MODEL_ID", "ibm/granite-34b-code-instruct")
    GRANITE_EMBEDDING_MODEL = os.getenv("GRANITE_EMBEDDING_MODEL", "ibm/slate-125m-english-rtrvr")

    # File Upload
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_UPLOAD_SIZE_MB", 100)) * 1024 * 1024
    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "uploads")
    REPOS_FOLDER = os.getenv("REPOS_FOLDER", "repos")
    REPORTS_FOLDER = os.getenv("REPORTS_FOLDER", "reports")
    VECTOR_STORE_FOLDER = os.getenv("VECTOR_STORE_FOLDER", "vector_store")

    # RAG
    RAG_CHUNK_SIZE = int(os.getenv("RAG_CHUNK_SIZE", 1000))
    RAG_CHUNK_OVERLAP = int(os.getenv("RAG_CHUNK_OVERLAP", 200))
    RAG_TOP_K = int(os.getenv("RAG_TOP_K", 5))
    EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")

    # GitHub
    GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")

    # Application
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    MAX_FILE_SIZE_KB = int(os.getenv("MAX_FILE_SIZE_KB", 500))
    SUPPORTED_EXTENSIONS = set(
        os.getenv(
            "SUPPORTED_EXTENSIONS",
            ".py,.js,.ts,.jsx,.tsx,.java,.go,.rb,.php,.cs,.cpp,.c,.h,.rs,.kt,.swift,.vue,.html,.css,.scss,.sql,.yaml,.yml,.json,.toml,.xml,.md,.txt,.sh,.bash,.dockerfile",
        ).split(",")
    )

    ALLOWED_UPLOAD_EXTENSIONS = {"zip"}
