"""
DevArchitect AI - Code Review Agent
"""
import re
import logging
from typing import Dict, List
from app.agents.agent_instructions import get_agent_system_prompt, AGENT_INSTRUCTIONS
from app.utils.watsonx_client import get_watsonx_client
from app.utils.repo_parser import count_lines, calculate_complexity

logger = logging.getLogger(__name__)


class CodeReviewAgent:
    """Reviews code quality, identifies issues, and recommends improvements."""

    def __init__(self):
        self.system_prompt = get_agent_system_prompt("code_review")
        self.review_cfg = AGENT_INSTRUCTIONS["review"]
        self.standards_cfg = AGENT_INSTRUCTIONS["coding_standards"]

    def review(self, contents: Dict[str, str], language_distribution: List[Dict]) -> Dict:
        """Run comprehensive code review."""
        logger.info("Starting code review analysis")

        issues = []
        metrics = []
        code_smells = []
        duplication_findings = []

        code_files = {
            path: content for path, content in contents.items()
            if not path.endswith((".md", ".txt", ".json", ".yaml", ".yml", ".toml"))
        }

        for filepath, content in code_files.items():
            lang = self._detect_lang(filepath)
            file_issues = []

            lines = content.splitlines()
            line_count = count_lines(content)
            complexity = calculate_complexity(content, lang)

            # Flag long functions
            long_funcs = self._find_long_functions(content, lang)
            for func in long_funcs:
                file_issues.append({
                    "type": "Long Method",
                    "severity": "Medium",
                    "line": func["line"],
                    "message": f"Function '{func['name']}' has {func['length']} lines (max: {self.standards_cfg['max_function_length_lines']})",
                    "effort": "medium",
                })

            # Magic numbers
            if self.review_cfg["flag_magic_numbers"]:
                for m in re.finditer(r'(?<!\w)(?<!\.)\b(\d{2,})\b(?!\.\d)', content):
                    if not re.search(r'#.*$', content[:m.start()].split('\n')[-1]):
                        file_issues.append({
                            "type": "Magic Number",
                            "severity": "Low",
                            "line": content[:m.start()].count('\n') + 1,
                            "message": f"Magic number {m.group(1)} — extract to named constant",
                            "effort": "low",
                        })
                        if len([i for i in file_issues if i["type"] == "Magic Number"]) >= 3:
                            break

            # TODO/FIXME flags
            if self.review_cfg["flag_todos_and_fixmes"]:
                for i, line in enumerate(lines, 1):
                    if re.search(r'\b(TODO|FIXME|HACK|XXX|BUG)\b', line, re.I):
                        file_issues.append({
                            "type": "TODO/FIXME",
                            "severity": "Low",
                            "line": i,
                            "message": f"Unresolved: {line.strip()[:80]}",
                            "effort": "low",
                        })

            # Empty except blocks
            if self.review_cfg["flag_empty_catch_blocks"]:
                for m in re.finditer(r'(?:except|catch)\s*(?:\([^)]*\))?\s*\{?\s*(?:pass\s*)?(?:\}|$)', content, re.M):
                    file_issues.append({
                        "type": "Empty Catch Block",
                        "severity": "Medium",
                        "line": content[:m.start()].count('\n') + 1,
                        "message": "Empty exception handler swallows errors silently",
                        "effort": "low",
                    })

            # Deeply nested code
            max_indent = max((len(line) - len(line.lstrip())) // 4 for line in lines if line.strip()) if lines else 0
            if max_indent > 4:
                file_issues.append({
                    "type": "Deep Nesting",
                    "severity": "Medium",
                    "line": 0,
                    "message": f"Deep nesting detected ({max_indent} levels). Refactor using early returns or extract methods.",
                    "effort": "medium",
                })

            # Complexity warning
            if complexity > self.standards_cfg["max_cyclomatic_complexity"] * 3:
                code_smells.append({
                    "file": filepath,
                    "smell": "High Cyclomatic Complexity",
                    "value": complexity,
                    "recommendation": "Break down complex functions into smaller, single-responsibility units.",
                })

            metrics.append({
                "file": filepath,
                "language": lang,
                "lines": line_count,
                "complexity": complexity,
                "issues_count": len(file_issues),
            })

            for issue in file_issues:
                issue["file"] = filepath
                issues.append(issue)

        # Duplicate detection (simplified)
        duplicates = self._detect_duplicates(code_files)

        # Dead code detection
        dead_code = self._detect_dead_code(code_files)

        # Build AI review for highest-complexity files
        top_files = sorted(metrics, key=lambda x: x["complexity"], reverse=True)[:3]
        ai_review = self._generate_ai_review(top_files, contents, issues)

        # Overall quality score
        quality_score = self._calculate_quality_score(metrics, issues, duplicates)

        return {
            "quality_score": quality_score,
            "total_issues": len(issues),
            "issues": sorted(issues, key=lambda x: {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}.get(x["severity"], 5))[:100],
            "code_smells": code_smells[:20],
            "duplicates": duplicates[:20],
            "dead_code": dead_code[:20],
            "metrics": sorted(metrics, key=lambda x: x["complexity"], reverse=True)[:50],
            "ai_review": ai_review,
        }

    def _detect_lang(self, filepath: str) -> str:
        ext = filepath.rsplit(".", 1)[-1].lower() if "." in filepath else ""
        return {"py": "Python", "js": "JavaScript", "ts": "TypeScript",
                "java": "Java", "go": "Go", "rb": "Ruby", "php": "PHP",
                "cs": "C#", "cpp": "C++", "rs": "Rust"}.get(ext, "Unknown")

    def _find_long_functions(self, content: str, language: str) -> List[Dict]:
        """Find overly long functions."""
        long_funcs = []
        max_len = self.standards_cfg["max_function_length_lines"]

        if language == "Python":
            pattern = re.compile(r'^(def\s+(\w+)\s*\()', re.M)
        else:
            pattern = re.compile(r'(?:function\s+(\w+)|(?:public|private|protected)?\s+\w+\s+(\w+)\s*\()', re.M)

        lines = content.splitlines()
        for match in pattern.finditer(content):
            start_line = content[:match.start()].count('\n')
            name = match.group(2) or match.group(1) or "anonymous"
            # Estimate function length by indentation
            func_lines = 0
            for i in range(start_line + 1, min(start_line + 300, len(lines))):
                if lines[i].strip() == "" or lines[i].startswith(" ") or lines[i].startswith("\t"):
                    func_lines += 1
                elif func_lines > 0:
                    break
            if func_lines > max_len:
                long_funcs.append({"name": name, "line": start_line + 1, "length": func_lines})
        return long_funcs

    def _detect_duplicates(self, code_files: Dict[str, str]) -> List[Dict]:
        """Detect near-duplicate code blocks."""
        duplicates = []
        file_list = list(code_files.items())
        threshold = self.review_cfg["flag_duplicate_code_threshold"]

        for i in range(min(len(file_list), 30)):
            path_a, content_a = file_list[i]
            lines_a = set(l.strip() for l in content_a.splitlines() if len(l.strip()) > 20)
            for j in range(i + 1, min(len(file_list), 30)):
                path_b, content_b = file_list[j]
                lines_b = set(l.strip() for l in content_b.splitlines() if len(l.strip()) > 20)
                if not lines_a or not lines_b:
                    continue
                intersection = lines_a & lines_b
                similarity = len(intersection) / max(len(lines_a), len(lines_b))
                if similarity >= threshold:
                    duplicates.append({
                        "file_a": path_a,
                        "file_b": path_b,
                        "similarity": round(similarity * 100, 1),
                        "shared_lines": len(intersection),
                        "recommendation": "Extract shared logic into a common module or utility.",
                    })
        return duplicates

    def _detect_dead_code(self, code_files: Dict[str, str]) -> List[Dict]:
        """Detect potentially unused functions/variables."""
        dead_code = []
        if not self.review_cfg["flag_dead_code"]:
            return dead_code

        all_content = " ".join(code_files.values())

        for filepath, content in code_files.items():
            # Python dead functions
            for match in re.finditer(r'^def\s+(_\w+)\s*\(', content, re.M):
                func_name = match.group(1)
                if func_name.startswith("__"):
                    continue
                if all_content.count(func_name) <= 1:
                    dead_code.append({
                        "file": filepath,
                        "type": "Potentially Unused Function",
                        "name": func_name,
                        "line": content[:match.start()].count('\n') + 1,
                        "recommendation": f"Verify '{func_name}' is actually used; remove if dead code.",
                    })

        return dead_code[:20]

    def _generate_ai_review(self, top_files: List, contents: Dict, issues: List) -> str:
        """Generate AI-powered code review narrative."""
        if not top_files:
            return "No significant code files found for review."

        review_snippets = []
        for file_meta in top_files[:2]:
            filepath = file_meta["file"]
            content = contents.get(filepath, "")
            review_snippets.append(f"\n### File: {filepath}\n```\n{content[:1500]}\n```\n")

        issue_summary = {}
        for issue in issues:
            t = issue["type"]
            issue_summary[t] = issue_summary.get(t, 0) + 1

        prompt = (
            f"{self.system_prompt}\n\n"
            f"Review these code files and provide actionable feedback:\n"
            f"{''.join(review_snippets)}\n\n"
            f"Issue summary found by static analysis:\n"
            f"{chr(10).join([f'- {k}: {v}' for k, v in issue_summary.items()])}\n\n"
            f"Provide:\n"
            f"1. **Overall Code Quality Assessment**\n"
            f"2. **Top 5 Critical Issues** with specific fix examples\n"
            f"3. **SOLID Principle Violations** if any\n"
            f"4. **Naming Convention Issues** if any\n"
            f"5. **Architecture Recommendations**\n"
            f"6. **Quick Wins** (easy improvements with high impact)\n"
            f"7. **Quality Score (0-100)** with grade letter\n"
        )

        client = get_watsonx_client()
        return client.generate(prompt, use_code_model=True, max_tokens=3000)

    def _calculate_quality_score(self, metrics: List, issues: List, duplicates: List) -> Dict:
        """Calculate overall code quality score."""
        if not metrics:
            return {"score": 0, "grade": "F", "breakdown": {}}

        severity_weights = {"Critical": 20, "High": 10, "Medium": 5, "Low": 2}
        deductions = sum(severity_weights.get(i["severity"], 1) for i in issues)
        deductions += len(duplicates) * 3

        avg_complexity = sum(m["complexity"] for m in metrics) / len(metrics)
        complexity_deduction = max(0, int((avg_complexity - 10) * 2))

        score = max(0, min(100, 100 - deductions - complexity_deduction))
        grade = "A" if score >= 90 else "B" if score >= 80 else "C" if score >= 70 else "D" if score >= 60 else "F"

        breakdown = {
            "maintainability": max(0, 100 - len([i for i in issues if i["severity"] in ["Critical", "High"]]) * 15),
            "complexity": max(0, 100 - complexity_deduction * 2),
            "duplication": max(0, 100 - len(duplicates) * 10),
            "issues": max(0, 100 - len(issues) * 2),
        }

        return {"score": score, "grade": grade, "breakdown": breakdown}
