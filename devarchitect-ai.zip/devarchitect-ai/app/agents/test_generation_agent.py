"""
DevArchitect AI - Test Case Generation Agent
"""
import logging
from typing import Dict, List
from app.agents.agent_instructions import get_agent_system_prompt
from app.utils.watsonx_client import get_watsonx_client
from app.utils.repo_parser import extract_python_structure, extract_js_structure

logger = logging.getLogger(__name__)


class TestGenerationAgent:
    """Generates unit tests, integration tests, and edge case test suites."""

    FRAMEWORK_MAP = {
        "Python": "pytest",
        "JavaScript": "jest",
        "TypeScript": "jest",
        "Java": "JUnit 5",
        "Go": "testing",
        "Ruby": "RSpec",
        "PHP": "PHPUnit",
        "C#": "xUnit",
        "Rust": "built-in test",
    }

    def __init__(self):
        self.system_prompt = get_agent_system_prompt("test_generation")

    def generate(self, contents: Dict[str, str], primary_language: str) -> Dict:
        """Generate test cases for the project."""
        logger.info("Starting test case generation")

        test_framework = self.FRAMEWORK_MAP.get(primary_language, "pytest")
        existing_tests = {
            path: content for path, content in contents.items()
            if "test" in path.lower() or "spec" in path.lower()
        }

        # Find functions/classes to test
        testable_units = self._extract_testable_units(contents, primary_language)

        # Generate tests for top functions
        generated_tests = []
        client = get_watsonx_client()

        # Batch by file for efficiency
        code_files = {
            path: content for path, content in contents.items()
            if not path.lower().endswith((".md", ".txt", ".json", ".yaml"))
            and not ("test" in path.lower() or "spec" in path.lower())
            and len(content) > 50
        }

        top_files = sorted(code_files.items(), key=lambda x: len(x[1]), reverse=True)[:4]

        for filepath, content in top_files:
            test_code = self._generate_file_tests(
                client, filepath, content, primary_language, test_framework
            )
            if test_code:
                generated_tests.append({
                    "source_file": filepath,
                    "test_framework": test_framework,
                    "test_code": test_code,
                    "test_count_estimate": test_code.count("def test_") + test_code.count("it("),
                })

        # Coverage analysis
        coverage = self._analyze_coverage(testable_units, existing_tests)

        # Edge cases summary
        edge_case_summary = self._generate_edge_case_summary(client, testable_units[:10], primary_language)

        return {
            "test_framework": test_framework,
            "generated_tests": generated_tests,
            "testable_units": testable_units[:50],
            "existing_tests": list(existing_tests.keys()),
            "coverage_analysis": coverage,
            "edge_case_summary": edge_case_summary,
            "total_functions_found": len(testable_units),
        }

    def _extract_testable_units(self, contents: Dict[str, str], language: str) -> List[Dict]:
        """Extract functions and classes that need tests."""
        units = []
        for filepath, content in contents.items():
            if "test" in filepath.lower() or "spec" in filepath.lower():
                continue
            if language == "Python":
                structure = extract_python_structure(content)
                for func in structure.get("functions", []):
                    units.append({
                        "type": "function",
                        "name": func["name"],
                        "file": filepath,
                        "line": func["line"],
                    })
                for cls in structure.get("classes", []):
                    for method in cls.get("methods", []):
                        units.append({
                            "type": "method",
                            "name": f"{cls['name']}.{method}",
                            "file": filepath,
                            "line": cls["line"],
                        })
            elif language in ("JavaScript", "TypeScript"):
                structure = extract_js_structure(content)
                for func in structure.get("functions", []):
                    units.append({"type": "function", "name": func, "file": filepath, "line": 0})
        return units

    def _generate_file_tests(self, client, filepath: str, content: str,
                              language: str, framework: str) -> str:
        prompt = (
            f"{self.system_prompt}\n\n"
            f"Generate comprehensive {framework} tests for this {language} file:\n\n"
            f"**File:** {filepath}\n"
            f"```{language.lower()}\n{content[:2000]}\n```\n\n"
            f"Generate tests that cover:\n"
            f"1. **Happy path** — normal expected behavior\n"
            f"2. **Edge cases** — boundary values, empty inputs, max values\n"
            f"3. **Error cases** — invalid inputs, exceptions, network failures\n"
            f"4. **Integration points** — API calls, database interactions (with mocks)\n\n"
            f"Requirements:\n"
            f"- Use {framework} framework with proper syntax\n"
            f"- Include test setup and teardown\n"
            f"- Mock external dependencies\n"
            f"- Add descriptive test names that document expected behavior\n"
            f"- Generate executable code, not pseudocode\n"
        )
        return client.generate(prompt, use_code_model=True, max_tokens=3000)

    def _analyze_coverage(self, testable_units: List, existing_tests: Dict) -> Dict:
        """Estimate test coverage."""
        if not testable_units:
            return {"estimated_coverage": 0, "tested_units": 0, "untested_units": 0}

        test_content = " ".join(existing_tests.values())
        tested = sum(1 for u in testable_units if u["name"].split(".")[-1] in test_content)
        total = len(testable_units)
        coverage_pct = round(tested / total * 100, 1) if total else 0

        return {
            "estimated_coverage": coverage_pct,
            "tested_units": tested,
            "untested_units": total - tested,
            "total_units": total,
            "grade": "A" if coverage_pct >= 80 else "B" if coverage_pct >= 60 else "C" if coverage_pct >= 40 else "F",
        }

    def _generate_edge_case_summary(self, client, units: List, language: str) -> str:
        if not units:
            return "No testable units found."
        units_text = "\n".join([f"- {u['type']}: {u['name']} ({u['file']})" for u in units[:10]])
        prompt = (
            f"{self.system_prompt}\n\n"
            f"For these {language} functions/methods, list the most important edge cases to test:\n"
            f"{units_text}\n\n"
            f"For each, provide:\n"
            f"1. What edge cases to cover\n"
            f"2. What boundary values to test\n"
            f"3. What error scenarios to handle\n"
            f"4. What mock objects are needed\n"
        )
        return client.generate(prompt, max_tokens=2000)
