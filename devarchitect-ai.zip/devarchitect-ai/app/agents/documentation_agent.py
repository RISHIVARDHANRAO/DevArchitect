"""
DevArchitect AI - Documentation Agent
"""
import logging
from typing import Dict, List
from app.agents.agent_instructions import get_agent_system_prompt, AGENT_INSTRUCTIONS
from app.utils.watsonx_client import get_watsonx_client

logger = logging.getLogger(__name__)


class DocumentationAgent:
    """Generates README, API docs, module descriptions, and developer guides."""

    def __init__(self):
        self.system_prompt = get_agent_system_prompt("documentation")
        self.doc_cfg = AGENT_INSTRUCTIONS["documentation"]

    def generate(self, repo_data: Dict, contents: Dict[str, str]) -> Dict:
        """Generate comprehensive documentation for the project."""
        logger.info("Starting documentation generation")

        client = get_watsonx_client()

        # Build context
        frameworks = repo_data.get("frameworks", [])
        lang_dist = repo_data.get("language_distribution", [])
        primary_lang = lang_dist[0]["language"] if lang_dist else "Unknown"
        deps = repo_data.get("dependencies", {})
        endpoints = repo_data.get("api_endpoints", [])
        health = repo_data.get("health_score", {})
        ai_summary = repo_data.get("ai_summary", "")

        # Generate README
        readme = self._generate_readme(client, frameworks, primary_lang, deps, endpoints, ai_summary, repo_data)

        # Generate API documentation
        api_docs = self._generate_api_docs(client, endpoints, contents)

        # Generate module docs
        module_docs = self._generate_module_docs(client, contents, primary_lang)

        # Generate installation guide
        install_guide = self._generate_install_guide(client, deps, frameworks, primary_lang)

        # Check existing documentation quality
        existing_docs = {
            path: content for path, content in contents.items()
            if path.lower().endswith(".md")
        }
        doc_quality = self._assess_doc_quality(existing_docs, repo_data)

        return {
            "readme": readme,
            "api_docs": api_docs,
            "module_docs": module_docs,
            "install_guide": install_guide,
            "doc_quality": doc_quality,
            "existing_docs": list(existing_docs.keys()),
        }

    def _generate_readme(self, client, frameworks, primary_lang, deps, endpoints, ai_summary, repo_data) -> str:
        sections = self.doc_cfg["readme_sections"]
        dep_list = []
        for pkg_manager, pkgs in deps.items():
            dep_list.extend(pkgs[:5])

        prompt = (
            f"{self.system_prompt}\n\n"
            f"Generate a professional, complete README.md for this project:\n\n"
            f"**Project Summary:** {ai_summary[:500] if ai_summary else 'A software project'}\n"
            f"**Primary Language:** {primary_lang}\n"
            f"**Frameworks:** {', '.join(frameworks) if frameworks else 'None detected'}\n"
            f"**Key Dependencies:** {', '.join(dep_list[:10])}\n"
            f"**API Endpoints:** {len(endpoints)}\n\n"
            f"Create a README.md with these sections: {', '.join(sections)}\n\n"
            f"Make it professional, developer-friendly with:\n"
            f"- Badges (build status, version, license)\n"
            f"- Clear installation steps\n"
            f"- Usage examples with code snippets\n"
            f"- Architecture overview\n"
            f"- Contributing guidelines\n"
            f"Use proper Markdown formatting with tables, code blocks, and links.\n"
        )
        return client.generate(prompt, max_tokens=4096)

    def _generate_api_docs(self, client, endpoints: List, contents: Dict) -> str:
        if not endpoints:
            return "No API endpoints detected in this project."

        endpoint_details = "\n".join([
            f"- {e.get('path', '/')} [{e.get('framework', 'Unknown')}] → {e.get('file', '')}"
            for e in endpoints[:20]
        ])

        # Find controller/route files
        route_files = {
            path: content for path, content in contents.items()
            if any(kw in path.lower() for kw in ["route", "api", "controller", "view", "handler"])
        }

        code_context = "\n".join([
            f"### {path}\n```\n{content[:600]}\n```"
            for path, content in list(route_files.items())[:3]
        ])

        prompt = (
            f"{self.system_prompt}\n\n"
            f"Generate API documentation for these endpoints:\n\n"
            f"**Endpoints:**\n{endpoint_details}\n\n"
            f"**Route Implementation Code:**\n{code_context}\n\n"
            f"Generate OpenAPI-style documentation including:\n"
            f"- Endpoint description\n"
            f"- HTTP method\n"
            f"- Request parameters/body\n"
            f"- Response format\n"
            f"- Authentication requirements\n"
            f"- Example requests and responses\n"
            f"Format as well-structured Markdown with code examples.\n"
        )
        return client.generate(prompt, max_tokens=3000)

    def _generate_module_docs(self, client, contents: Dict, primary_lang: str) -> str:
        # Select most important files
        code_files = {
            path: content for path, content in contents.items()
            if not path.lower().endswith((".md", ".txt", ".json", ".yaml", ".yml"))
            and len(content) > 100
        }

        top_files = sorted(code_files.items(), key=lambda x: len(x[1]), reverse=True)[:5]
        code_samples = "\n".join([
            f"### {path}\n```{primary_lang.lower()}\n{content[:800]}\n```"
            for path, content in top_files
        ])

        prompt = (
            f"{self.system_prompt}\n\n"
            f"Generate comprehensive module documentation for these {primary_lang} files:\n\n"
            f"{code_samples}\n\n"
            f"For each module provide:\n"
            f"- Module purpose and responsibility\n"
            f"- Key classes and their roles\n"
            f"- Important functions with parameters and return values\n"
            f"- Usage examples\n"
            f"- Dependencies and integration points\n"
            f"Use proper docstring format for {primary_lang}.\n"
        )
        return client.generate(prompt, use_code_model=True, max_tokens=3000)

    def _generate_install_guide(self, client, deps: Dict, frameworks: List, primary_lang: str) -> str:
        dep_managers = list(deps.keys())
        all_deps = []
        for pkgs in deps.values():
            all_deps.extend(pkgs[:10])

        prompt = (
            f"{self.system_prompt}\n\n"
            f"Generate a complete installation and setup guide for this {primary_lang} project.\n\n"
            f"**Dependency Managers:** {', '.join(dep_managers) if dep_managers else 'Not detected'}\n"
            f"**Frameworks:** {', '.join(frameworks) if frameworks else 'Unknown'}\n"
            f"**Key Dependencies:** {', '.join(all_deps[:15])}\n\n"
            f"Include:\n"
            f"1. Prerequisites (system requirements)\n"
            f"2. Step-by-step installation commands\n"
            f"3. Environment configuration (.env setup)\n"
            f"4. Database setup (if applicable)\n"
            f"5. Running the application\n"
            f"6. Running tests\n"
            f"7. Docker deployment (if applicable)\n"
            f"8. Production deployment checklist\n"
            f"9. Troubleshooting common issues\n"
            f"Use precise shell commands and clear instructions.\n"
        )
        return client.generate(prompt, max_tokens=2000)

    def _assess_doc_quality(self, existing_docs: Dict, repo_data: Dict) -> Dict:
        """Assess quality of existing documentation."""
        if not existing_docs:
            return {
                "score": 0,
                "grade": "F",
                "missing": ["README.md", "API documentation", "Installation guide", "Contributing guide"],
                "improvements": ["Add a README.md with project overview and setup instructions"],
            }

        score = min(len(existing_docs) * 20, 60)
        missing = []
        content_lower = " ".join(existing_docs.values()).lower()

        if "installation" not in content_lower and "install" not in content_lower:
            missing.append("Installation instructions")
            score = max(0, score - 10)
        if "usage" not in content_lower and "example" not in content_lower:
            missing.append("Usage examples")
            score = max(0, score - 10)
        if "api" not in content_lower and repo_data.get("api_endpoints"):
            missing.append("API documentation")
            score = max(0, score - 10)
        if "contributing" not in content_lower:
            missing.append("Contributing guide")
            score = max(0, score - 5)
        if "license" not in content_lower:
            missing.append("License information")
            score = max(0, score - 5)

        grade = "A" if score >= 90 else "B" if score >= 75 else "C" if score >= 60 else "D" if score >= 45 else "F"
        return {
            "score": score,
            "grade": grade,
            "existing_files": list(existing_docs.keys()),
            "missing": missing,
        }
