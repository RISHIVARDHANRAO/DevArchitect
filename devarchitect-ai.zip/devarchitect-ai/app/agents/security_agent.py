"""
DevArchitect AI - Security Analysis Agent
"""
import re
import logging
from typing import Dict, List
from app.agents.agent_instructions import get_agent_system_prompt, AGENT_INSTRUCTIONS
from app.utils.watsonx_client import get_watsonx_client

logger = logging.getLogger(__name__)


class SecurityAnalysisAgent:
    """Detects security vulnerabilities, exposed secrets, and insecure patterns."""

    VULNERABILITY_PATTERNS = {
        "SQL Injection": {
            "severity": "Critical",
            "patterns": [
                r'(?:execute|query|cursor\.execute)\s*\(\s*["\'].*?%s.*?["\']',
                r'(?:execute|query)\s*\(\s*f["\'].*?\{.*?\}.*?["\']',
                r'sql\s*=\s*["\'].*?\+\s*\w+',
                r'SELECT\s+.+\s+FROM\s+.+\s+WHERE\s+.+\s*=\s*["\']?\s*\+',
            ],
            "remediation": "Use parameterized queries or ORM. Never concatenate user input into SQL strings.",
            "cwe": "CWE-89",
            "owasp": "A03:2021 - Injection",
        },
        "XSS (Cross-Site Scripting)": {
            "severity": "High",
            "patterns": [
                r'innerHTML\s*=\s*(?!["\']\s*["\'])',
                r'document\.write\s*\(',
                r'\.html\(\s*(?!["\']\s*["\']\s*\))',
                r'dangerouslySetInnerHTML',
                r'v-html\s*=',
            ],
            "remediation": "Use textContent instead of innerHTML. Sanitize all user inputs. Use Content Security Policy headers.",
            "cwe": "CWE-79",
            "owasp": "A03:2021 - Injection",
        },
        "Hardcoded Credentials": {
            "severity": "Critical",
            "patterns": [
                r'(?i)(?:password|passwd|pwd)\s*=\s*["\'][^"\']{3,}["\']',
                r'(?i)(?:api_key|apikey|api-key)\s*=\s*["\'][A-Za-z0-9_\-]{10,}["\']',
                r'(?i)(?:secret|token|auth)\s*=\s*["\'][^"\']{8,}["\']',
                r'(?i)(?:private_key|secret_key)\s*[:=]\s*["\'][^"\']{10,}',
            ],
            "remediation": "Move secrets to environment variables or a secrets manager. Never commit credentials to source control.",
            "cwe": "CWE-798",
            "owasp": "A07:2021 - Identification and Authentication Failures",
        },
        "Command Injection": {
            "severity": "Critical",
            "patterns": [
                r'os\.system\s*\(',
                r'subprocess\.(?:call|run|Popen)\s*\([^)]*shell\s*=\s*True',
                r'exec\s*\(\s*(?:request|input|params)',
                r'eval\s*\(\s*(?:request|input|user)',
            ],
            "remediation": "Avoid shell=True. Use subprocess with argument lists. Validate and sanitize all user input before system calls.",
            "cwe": "CWE-78",
            "owasp": "A03:2021 - Injection",
        },
        "Path Traversal": {
            "severity": "High",
            "patterns": [
                r'open\s*\(\s*(?:request|input|params|user)',
                r'(?:os\.path\.join|Path)\s*\([^)]*(?:request|input|params)',
                r'readFile\s*\(\s*(?:req|request)\.',
                r'\.\./\.\.',
            ],
            "remediation": "Validate and sanitize file paths. Use os.path.realpath() and verify the path stays within allowed directories.",
            "cwe": "CWE-22",
            "owasp": "A01:2021 - Broken Access Control",
        },
        "Insecure Deserialization": {
            "severity": "High",
            "patterns": [
                r'pickle\.loads?\s*\(',
                r'yaml\.load\s*\([^)]*(?!Loader=yaml\.SafeLoader)',
                r'marshal\.loads?\s*\(',
                r'unserialize\s*\(\s*(?:request|input|user)',
            ],
            "remediation": "Use safe deserialization methods. For YAML, use yaml.safe_load(). Avoid pickle with untrusted data.",
            "cwe": "CWE-502",
            "owasp": "A08:2021 - Software and Data Integrity Failures",
        },
        "Weak Cryptography": {
            "severity": "High",
            "patterns": [
                r'(?i)md5\s*\(',
                r'(?i)sha1\s*\(',
                r'hashlib\.md5\s*\(',
                r'hashlib\.sha1\s*\(',
                r'DES\.|RC4\.',
                r'(?i)(?:algorithm|cipher)\s*=\s*["\'](?:md5|sha1|des|rc4)["\']',
            ],
            "remediation": "Use SHA-256 or stronger. Use bcrypt/argon2 for passwords. Use AES-256 for symmetric encryption.",
            "cwe": "CWE-327",
            "owasp": "A02:2021 - Cryptographic Failures",
        },
        "Insecure HTTP": {
            "severity": "Medium",
            "patterns": [
                r'http://(?!localhost|127\.0\.0\.1)',
                r'verify\s*=\s*False',
                r'ssl\._create_unverified_context',
                r'ALLOW_ALL_ORIGINS\s*=\s*True',
            ],
            "remediation": "Use HTTPS. Verify SSL certificates. Configure CORS properly.",
            "cwe": "CWE-319",
            "owasp": "A02:2021 - Cryptographic Failures",
        },
        "CSRF Vulnerability": {
            "severity": "High",
            "patterns": [
                r'csrf_exempt',
                r'CSRF_COOKIE_SECURE\s*=\s*False',
                r'WTF_CSRF_ENABLED\s*=\s*False',
                r'csrf_disabled\s*=\s*True',
            ],
            "remediation": "Enable CSRF protection for all state-changing requests. Use CSRF tokens.",
            "cwe": "CWE-352",
            "owasp": "A01:2021 - Broken Access Control",
        },
        "Debug Mode Enabled": {
            "severity": "Medium",
            "patterns": [
                r'DEBUG\s*=\s*True',
                r'app\.run\([^)]*debug\s*=\s*True',
                r'FLASK_DEBUG\s*=\s*1',
            ],
            "remediation": "Disable debug mode in production. Use environment variables to control debug settings.",
            "cwe": "CWE-215",
            "owasp": "A05:2021 - Security Misconfiguration",
        },
    }

    def __init__(self):
        self.system_prompt = get_agent_system_prompt("security")
        self.security_cfg = AGENT_INSTRUCTIONS["security"]

    def analyze(self, contents: Dict[str, str]) -> Dict:
        """Run comprehensive security analysis."""
        logger.info("Starting security analysis")

        findings = []
        secret_findings = []
        stats = {s: 0 for s in ["Critical", "High", "Medium", "Low", "Informational"]}

        for filepath, content in contents.items():
            # Skip non-code files for some checks
            is_config = any(filepath.lower().endswith(ext) for ext in [".yml", ".yaml", ".json", ".toml", ".env", ".ini", ".cfg"])

            # Vulnerability patterns
            for vuln_type, vuln_data in self.VULNERABILITY_PATTERNS.items():
                for pattern in vuln_data["patterns"]:
                    for match in re.finditer(pattern, content, re.M | re.I):
                        line_num = content[:match.start()].count('\n') + 1
                        line_content = content.splitlines()[line_num - 1] if line_num <= len(content.splitlines()) else ""

                        findings.append({
                            "type": vuln_type,
                            "severity": vuln_data["severity"],
                            "file": filepath,
                            "line": line_num,
                            "code_snippet": line_content.strip()[:120],
                            "remediation": vuln_data["remediation"],
                            "cwe": vuln_data.get("cwe", ""),
                            "owasp": vuln_data.get("owasp", ""),
                        })
                        stats[vuln_data["severity"]] = stats.get(vuln_data["severity"], 0) + 1
                        break  # One finding per pattern per file to avoid noise

            # Secret detection
            for pattern in self.security_cfg["secret_patterns"]:
                for match in re.finditer(pattern, content, re.M | re.I):
                    line_num = content[:match.start()].count('\n') + 1
                    matched_text = match.group(0)
                    # Mask the secret value
                    masked = re.sub(r'=\s*["\'][^"\']+["\']', '= "***REDACTED***"', matched_text)
                    secret_findings.append({
                        "type": "Exposed Secret",
                        "severity": "Critical",
                        "file": filepath,
                        "line": line_num,
                        "masked_match": masked[:100],
                        "remediation": "Move to environment variables. Rotate the compromised secret immediately.",
                        "cwe": "CWE-798",
                        "owasp": "A07:2021 - Identification and Authentication Failures",
                    })
                    stats["Critical"] += 1
                    break  # One per pattern per file

        all_findings = secret_findings + findings
        all_findings = sorted(all_findings, key=lambda x: {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}.get(x["severity"], 4))

        # AI-powered security narrative
        ai_report = self._generate_ai_security_report(all_findings[:10], contents)

        # Risk score
        risk_score = self._calculate_risk_score(stats)

        return {
            "risk_score": risk_score,
            "total_findings": len(all_findings),
            "statistics": stats,
            "findings": all_findings[:50],
            "secret_findings": secret_findings[:20],
            "ai_report": ai_report,
            "owasp_coverage": self._map_owasp_coverage(all_findings),
        }

    def _generate_ai_security_report(self, findings: List, contents: Dict) -> str:
        """Generate AI security analysis narrative."""
        if not findings:
            findings_text = "No critical vulnerabilities detected by static analysis."
        else:
            findings_text = "\n".join([
                f"- [{f['severity']}] {f['type']} in {f['file']}:{f['line']}: {f.get('code_snippet', '')[:60]}"
                for f in findings[:10]
            ])

        # Sample a few files for deep analysis
        sample_files = list(contents.items())[:3]
        code_samples = "\n".join([f"### {path}\n```\n{content[:800]}\n```" for path, content in sample_files])

        prompt = (
            f"{self.system_prompt}\n\n"
            f"Perform security analysis on this codebase:\n\n"
            f"**Static Analysis Findings:**\n{findings_text}\n\n"
            f"**Code Samples:**\n{code_samples}\n\n"
            f"Provide:\n"
            f"1. **Security Risk Summary**\n"
            f"2. **Critical Vulnerabilities** (detailed analysis of each)\n"
            f"3. **Authentication & Authorization** assessment\n"
            f"4. **Data Validation** assessment\n"
            f"5. **Secure Configuration** review\n"
            f"6. **Security Best Practices** missing from this codebase\n"
            f"7. **Prioritized Remediation Plan** (steps 1-5)\n"
            f"8. **Security Score (0-100)**\n"
        )

        client = get_watsonx_client()
        return client.generate(prompt, max_tokens=3000)

    def _calculate_risk_score(self, stats: Dict) -> Dict:
        """Calculate security risk score."""
        weights = {"Critical": 30, "High": 15, "Medium": 5, "Low": 1, "Informational": 0}
        risk = sum(stats.get(s, 0) * w for s, w in weights.items())
        security_score = max(0, min(100, 100 - risk))
        grade = "A" if security_score >= 90 else "B" if security_score >= 75 else "C" if security_score >= 60 else "D" if security_score >= 45 else "F"
        return {
            "score": security_score,
            "grade": grade,
            "risk_level": "Low" if security_score >= 80 else "Medium" if security_score >= 60 else "High" if security_score >= 40 else "Critical",
        }

    def _map_owasp_coverage(self, findings: List) -> Dict:
        """Map findings to OWASP Top 10."""
        owasp_map = {}
        for f in findings:
            category = f.get("owasp", "Other")
            owasp_map[category] = owasp_map.get(category, 0) + 1
        return owasp_map
