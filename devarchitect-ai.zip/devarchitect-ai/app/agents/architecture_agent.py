"""
DevArchitect AI - Architecture Agent
"""
import logging
from typing import Dict, List
from app.agents.agent_instructions import get_agent_system_prompt
from app.utils.watsonx_client import get_watsonx_client

logger = logging.getLogger(__name__)


class ArchitectureAgent:
    """Generates architecture summaries, Mermaid diagrams, and design analysis."""

    def __init__(self):
        self.system_prompt = get_agent_system_prompt("architecture")

    def analyze(self, repo_data: Dict, contents: Dict[str, str]) -> Dict:
        """Generate comprehensive architecture analysis."""
        logger.info("Starting architecture analysis")

        files = list(contents.keys())
        frameworks = repo_data.get("frameworks", [])
        languages = repo_data.get("language_distribution", [])
        deps = repo_data.get("dependencies", {})
        endpoints = repo_data.get("api_endpoints", [])

        # Module grouping
        modules = self._group_into_modules(files)

        prompt = (
            f"{self.system_prompt}\n\n"
            f"Analyze this project's architecture:\n\n"
            f"**Detected Frameworks:** {', '.join(frameworks) if frameworks else 'None'}\n"
            f"**Primary Language:** {languages[0]['language'] if languages else 'Unknown'}\n"
            f"**File Structure:**\n{chr(10).join(files[:40])}\n\n"
            f"**Modules/Packages:**\n{chr(10).join([f'- {m}' for m in list(modules.keys())[:15]])}\n\n"
            f"**API Endpoints ({len(endpoints)}):**\n"
            f"{chr(10).join([f'  {e[\"path\"]} ({e[\"framework\"]})' for e in endpoints[:15]])}\n\n"
            f"**Dependencies:**\n{chr(10).join([f'- {k}: {len(v)} packages' for k, v in deps.items()])}\n\n"
            f"Provide:\n"
            f"1. **Architecture Pattern** with explanation\n"
            f"2. **System Components** and their responsibilities\n"
            f"3. **Data Flow** description\n"
            f"4. **Integration Points** (APIs, databases, external services)\n"
            f"5. **Design Patterns** identified\n"
            f"6. **Architecture Strengths** and **Weaknesses**\n"
            f"7. **Mermaid.js Architecture Diagram** (graph TD or flowchart LR)\n"
            f"8. **Module Dependency Diagram** in Mermaid\n"
            f"9. **Improvement Recommendations** for the architecture\n"
        )

        client = get_watsonx_client()
        ai_analysis = client.generate(prompt, max_tokens=3000)

        mermaid_diagram = self._extract_mermaid(ai_analysis)
        if not mermaid_diagram:
            mermaid_diagram = self._generate_default_mermaid(modules, frameworks, endpoints)

        dep_graph = self._build_dependency_graph(contents)

        return {
            "ai_analysis": ai_analysis,
            "mermaid_diagram": mermaid_diagram,
            "dependency_graph": dep_graph,
            "modules": modules,
            "patterns_detected": self._detect_patterns(files, contents),
        }

    def _group_into_modules(self, files: List[str]) -> Dict:
        """Group files into logical modules/packages."""
        modules = {}
        for f in files:
            parts = f.replace("\\", "/").split("/")
            if len(parts) > 1:
                module = parts[0]
                if module not in modules:
                    modules[module] = []
                modules[module].append(f)
            else:
                modules.setdefault("root", []).append(f)
        return modules

    def _extract_mermaid(self, text: str) -> str:
        """Extract Mermaid diagram from generated text."""
        import re
        patterns = [
            r"```mermaid\s*([\s\S]+?)```",
            r"((?:graph|flowchart|sequenceDiagram|classDiagram|erDiagram|gitGraph)[\s\S]+?)(?:\n\n|\Z)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1).strip()
        return ""

    def _generate_default_mermaid(self, modules: Dict, frameworks: List, endpoints: List) -> str:
        """Generate a fallback Mermaid diagram."""
        lines = ["graph TD"]
        module_list = list(modules.keys())[:8]
        for i, module in enumerate(module_list):
            safe_name = module.replace("-", "_").replace(".", "_")
            lines.append(f'    {safe_name}["{module}"]')
        if len(module_list) > 1:
            for i in range(len(module_list) - 1):
                a = module_list[i].replace("-", "_").replace(".", "_")
                b = module_list[i + 1].replace("-", "_").replace(".", "_")
                lines.append(f"    {a} --> {b}")
        if endpoints:
            lines.append('    CLIENT["Client"]')
            lines.append(f'    API["API Layer ({len(endpoints)} endpoints)"]')
            lines.append("    CLIENT --> API")
            if module_list:
                lines.append(f"    API --> {module_list[0].replace('-', '_').replace('.', '_')}")
        return "\n".join(lines)

    def _build_dependency_graph(self, contents: Dict[str, str]) -> Dict:
        """Build internal file dependency graph."""
        import re
        graph = {"nodes": [], "edges": []}
        node_set = set()
        files = list(contents.keys())

        for filepath in files[:50]:
            content = contents[filepath]
            node_name = filepath.replace("\\", "/")
            if node_name not in node_set:
                graph["nodes"].append({"id": node_name, "label": node_name.split("/")[-1]})
                node_set.add(node_name)

            # Python imports
            for match in re.finditer(r"from\s+([\w.]+)\s+import|import\s+([\w.]+)", content):
                imp = match.group(1) or match.group(2)
                if imp:
                    for target in files:
                        target_norm = target.replace("\\", "/").replace("/", ".").rstrip(".py")
                        if imp in target_norm or target_norm.endswith(imp.split(".")[-1]):
                            graph["edges"].append({"from": node_name, "to": target.replace("\\", "/")})

        return graph

    def _detect_patterns(self, files: List[str], contents: Dict[str, str]) -> List[str]:
        """Detect architectural and design patterns."""
        patterns = []
        all_content = " ".join(contents.values()).lower()
        all_files = " ".join(files).lower()

        checks = {
            "MVC Pattern": ["model", "view", "controller"],
            "Repository Pattern": ["repository", "repo"],
            "Factory Pattern": ["factory"],
            "Observer Pattern": ["observer", "event", "listener", "subscriber"],
            "Singleton Pattern": ["singleton", "instance", "_instance"],
            "REST API": ["get", "post", "put", "delete", "patch"],
            "Microservices": ["service", "gateway", "docker-compose"],
            "Event-Driven": ["event", "message", "queue", "kafka", "rabbitmq"],
            "CQRS": ["command", "query", "handler"],
            "Clean Architecture": ["usecase", "entity", "adapter"],
        }

        for pattern, keywords in checks.items():
            if sum(1 for kw in keywords if kw in all_files or kw in all_content) >= 2:
                patterns.append(pattern)

        return patterns
