"""
DevArchitect AI - Performance Optimization Agent
"""
import re
import logging
from typing import Dict, List
from app.agents.agent_instructions import get_agent_system_prompt
from app.utils.watsonx_client import get_watsonx_client

logger = logging.getLogger(__name__)


class PerformanceAgent:
    """Identifies performance bottlenecks and optimization opportunities."""

    PERFORMANCE_PATTERNS = {
        "N+1 Query": {
            "severity": "High",
            "patterns": [
                r'for\s+\w+\s+in\s+\w+\.(?:objects\.all|filter|get)\(',
                r'\.objects\.all\(\)[^.]*for',
                r'for.*in.*\.find\(.*\).*\n.*\.find\(',
            ],
            "description": "N+1 database query pattern detected — fetches data in a loop",
            "fix": "Use select_related(), prefetch_related(), or JOIN queries to batch database calls.",
            "big_o": "O(n) → O(1) with proper batching",
        },
        "Inefficient Loop": {
            "severity": "Medium",
            "patterns": [
                r'for\s+\w+\s+in\s+range\(len\(',
                r'while\s+True.*sleep',
                r'\.append\(.*\)\s*$',
            ],
            "description": "Inefficient iteration pattern",
            "fix": "Use list comprehensions, generators, or enumerate() for more efficient iteration.",
            "big_o": "Potential O(n²) → O(n)",
        },
        "Blocking I/O in Sync Context": {
            "severity": "High",
            "patterns": [
                r'time\.sleep\(\d+\)',
                r'requests\.get\(.*\)(?!\s*async)',
                r'open\([^)]+\)(?!\s*async)',
            ],
            "description": "Synchronous blocking I/O operation",
            "fix": "Use async/await with aiohttp, aiofiles for non-blocking I/O operations.",
            "big_o": "Blocks thread — consider async or thread pooling",
        },
        "String Concatenation in Loop": {
            "severity": "Medium",
            "patterns": [
                r'for\s+\w+[^:]+:\s*\n\s*\w+\s*\+=\s*["\']',
                r'\w+\s*\+=\s*(?:str|f)["\']',
            ],
            "description": "String concatenation in loop creates O(n²) string operations",
            "fix": "Use a list and ''.join() at the end, or use StringBuilder pattern.",
            "big_o": "O(n²) → O(n)",
        },
        "Missing Cache": {
            "severity": "Medium",
            "patterns": [
                r'def\s+get_\w+\(.*\):\s*\n(?!\s*@cache|\s*cache)',
                r'@app\.route.*\n(?!\s*@cache)',
            ],
            "description": "Potentially cacheable operation without caching",
            "fix": "Add caching with @lru_cache, Redis, or Memcached for frequently called expensive operations.",
            "big_o": "O(n) per call → O(1) with cache",
        },
        "Inefficient Data Structure": {
            "severity": "Medium",
            "patterns": [
                r'if\s+\w+\s+in\s+\w+_list',
                r'\.index\(',
                r'list\.remove\(',
            ],
            "description": "Linear search in list — should use set or dict for O(1) lookup",
            "fix": "Convert to set or dict for O(1) membership testing: `if item in my_set`",
            "big_o": "O(n) → O(1)",
        },
        "Unnecessary Re-computation": {
            "severity": "Low",
            "patterns": [
                r'len\(\w+\)\s+(?:>|<|>=|<=|==)\s*\d+.*len\(\w+\)',
                r'for\s+\w+\s+in\s+\w+:\s*\n\s+\w+\s*=\s*(?:len|sorted|list)',
            ],
            "description": "Redundant computation inside loops",
            "fix": "Extract expensive computations outside of loops.",
            "big_o": "O(n²) → O(n)",
        },
        "Large Object Loaded in Memory": {
            "severity": "High",
            "patterns": [
                r'\.read\(\)',
                r'\.readlines\(\)',
                r'json\.load\(',
                r'pickle\.load\(',
            ],
            "description": "Entire file/object loaded into memory at once",
            "fix": "Use streaming/chunked reading, generators, or pagination for large data.",
            "big_o": "O(n) memory → O(1) with streaming",
        },
    }

    def __init__(self):
        self.system_prompt = get_agent_system_prompt("performance")

    def analyze(self, contents: Dict[str, str]) -> Dict:
        """Run performance analysis on the codebase."""
        logger.info("Starting performance analysis")

        findings = []
        hotspots = []
        stats = {"High": 0, "Medium": 0, "Low": 0}

        for filepath, content in contents.items():
            file_findings = []

            for issue_type, issue_data in self.PERFORMANCE_PATTERNS.items():
                for pattern in issue_data["patterns"]:
                    for match in re.finditer(pattern, content, re.M | re.I):
                        line_num = content[:match.start()].count('\n') + 1
                        line_content = ""
                        lines = content.splitlines()
                        if 0 < line_num <= len(lines):
                            line_content = lines[line_num - 1].strip()

                        finding = {
                            "type": issue_type,
                            "severity": issue_data["severity"],
                            "file": filepath,
                            "line": line_num,
                            "code_snippet": line_content[:100],
                            "description": issue_data["description"],
                            "fix": issue_data["fix"],
                            "big_o_improvement": issue_data.get("big_o", ""),
                        }
                        file_findings.append(finding)
                        stats[issue_data["severity"]] = stats.get(issue_data["severity"], 0) + 1
                        break  # One per pattern per file

            if file_findings:
                # Calculate a hotspot score
                hotspot_score = sum({"High": 10, "Medium": 5, "Low": 2}.get(f["severity"], 1) for f in file_findings)
                hotspots.append({
                    "file": filepath,
                    "score": hotspot_score,
                    "findings_count": len(file_findings),
                })

            findings.extend(file_findings)

        # Sort by severity
        findings.sort(key=lambda x: {"High": 0, "Medium": 1, "Low": 2}.get(x["severity"], 3))
        hotspots.sort(key=lambda x: x["score"], reverse=True)

        # AI performance analysis
        ai_report = self._generate_ai_report(findings[:10], list(contents.items())[:3])

        perf_score = max(0, min(100, 100 - stats["High"] * 15 - stats["Medium"] * 5 - stats["Low"] * 1))

        return {
            "performance_score": perf_score,
            "total_findings": len(findings),
            "statistics": stats,
            "findings": findings[:50],
            "hotspots": hotspots[:10],
            "ai_report": ai_report,
        }

    def _generate_ai_report(self, findings: List, code_samples: List) -> str:
        """Generate AI performance analysis."""
        findings_text = "\n".join([
            f"- [{f['severity']}] {f['type']} in {f['file']}:{f['line']}: {f['description']}"
            for f in findings
        ]) or "No critical patterns detected."

        samples_text = "\n".join([
            f"### {path}\n```\n{content[:600]}\n```"
            for path, content in code_samples[:2]
        ])

        prompt = (
            f"{self.system_prompt}\n\n"
            f"**Performance Issues Found:**\n{findings_text}\n\n"
            f"**Code Samples:**\n{samples_text}\n\n"
            f"Provide:\n"
            f"1. **Performance Overview** with severity assessment\n"
            f"2. **Top 5 Performance Bottlenecks** with Big-O analysis\n"
            f"3. **Database Query Optimizations** if applicable\n"
            f"4. **Memory Optimization Opportunities**\n"
            f"5. **Caching Strategy** recommendations\n"
            f"6. **Async/Concurrent** processing opportunities\n"
            f"7. **Before/After Code Examples** for top 3 fixes\n"
            f"8. **Performance Score (0-100)** with improvement potential\n"
        )

        client = get_watsonx_client()
        return client.generate(prompt, use_code_model=True, max_tokens=3000)
