"""
DevArchitect AI - Repository Q&A Agent (RAG)
"""
import logging
from typing import Dict, List, Optional
from app.agents.agent_instructions import get_agent_system_prompt
from app.utils.watsonx_client import get_watsonx_client

logger = logging.getLogger(__name__)


class RepositoryQAAgent:
    """Answers natural language questions about the repository using RAG."""

    def __init__(self):
        self.system_prompt = get_agent_system_prompt("rag_qa")

    def answer(self, question: str, repo_data: Dict,
               rag_service, session_id: str) -> Dict:
        """Answer a question using RAG over the repository."""
        logger.info(f"RAG Q&A: {question[:80]}")

        client = get_watsonx_client()

        # Retrieve relevant context
        context_docs = []
        context_text = ""

        if rag_service and rag_service.has_index(session_id):
            try:
                context_docs = rag_service.search(question, session_id, k=6)
                context_text = "\n\n---\n".join([
                    f"**File:** {doc['source']} (lines {doc.get('start_line', '?')}-{doc.get('end_line', '?')})\n"
                    f"```\n{doc['content']}\n```"
                    for doc in context_docs
                ])
            except Exception as e:
                logger.error(f"RAG search error: {e}")
                context_text = "Repository context unavailable."
        else:
            # Fallback: use repo summary
            context_text = (
                f"Repository Summary: {repo_data.get('ai_summary', 'No summary available')}\n"
                f"Languages: {', '.join([l['language'] for l in repo_data.get('language_distribution', [])[:5]])}\n"
                f"Frameworks: {', '.join(repo_data.get('frameworks', []))}\n"
                f"Files: {repo_data.get('total_files', 0)}\n"
            )

        # Build prompt
        prompt = (
            f"{self.system_prompt}\n\n"
            f"Answer the following question about the repository based on the context below.\n\n"
            f"**Question:** {question}\n\n"
            f"**Repository Context:**\n{context_text}\n\n"
            f"**Repository Overview:**\n"
            f"- Total files: {repo_data.get('total_files', 'Unknown')}\n"
            f"- Primary language: {(repo_data.get('language_distribution') or [{}])[0].get('language', 'Unknown')}\n"
            f"- Frameworks: {', '.join(repo_data.get('frameworks', []))}\n"
            f"- Architecture: {repo_data.get('ai_summary', '')[:200]}\n\n"
            f"Instructions:\n"
            f"- Answer based ONLY on the provided context\n"
            f"- Cite specific files and line numbers when relevant\n"
            f"- If context is insufficient, say so clearly\n"
            f"- Be concise but complete\n"
        )

        answer = client.generate(prompt, max_tokens=2048, temperature=0.1)

        return {
            "question": question,
            "answer": answer,
            "sources": [{"file": d["source"], "preview": d["content"][:100]} for d in context_docs[:3]],
            "context_found": len(context_docs),
        }

    def chat(self, messages: List[Dict], repo_data: Dict,
             rag_service, session_id: str) -> str:
        """Multi-turn conversation about the repository."""
        client = get_watsonx_client()

        last_question = messages[-1]["content"] if messages else ""

        # Retrieve context for last question
        context_text = ""
        if rag_service and rag_service.has_index(session_id):
            try:
                context_docs = rag_service.search(last_question, session_id, k=4)
                context_text = "\n".join([
                    f"[{doc['source']}]: {doc['content'][:300]}"
                    for doc in context_docs
                ])
            except Exception:
                pass

        # Build conversation history
        history = "\n".join([
            f"{'User' if m['role'] == 'user' else 'Assistant'}: {m['content']}"
            for m in messages[-8:]  # Last 8 messages for context window
        ])

        repo_summary = (
            f"Repository: {repo_data.get('total_files', 0)} files, "
            f"Primary: {(repo_data.get('language_distribution') or [{}])[0].get('language', 'Unknown')}, "
            f"Frameworks: {', '.join(repo_data.get('frameworks', [])[:3])}"
        )

        prompt = (
            f"{self.system_prompt}\n\n"
            f"You are analyzing a codebase. {repo_summary}\n\n"
            f"**Relevant Code Context:**\n{context_text}\n\n"
            f"**Conversation History:**\n{history}\n\n"
            f"Respond to the user's latest message. Be helpful, specific, and cite files when relevant.\n"
            f"Assistant:"
        )

        return client.generate(prompt, max_tokens=2048, temperature=0.3)
