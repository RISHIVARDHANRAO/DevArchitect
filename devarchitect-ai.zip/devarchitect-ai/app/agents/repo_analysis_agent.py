"""
DevArchitect AI - Repository Analysis Agent
"""
import json
import logging
from collections import Counter
from typing import Dict, List
from app.agents.agent_instructions import get_agent_system_prompt
from app.utils.watsonx_client import get_watsonx_client
from app.utils.repo_parser import (
    collect_files, get_language, detect_frameworks, detect_license,
    extract_dependencies, detect_api_endpoints, build_file_tree,
    count_lines, calculate_complexity
)

logger = logging.getLogger(__name__)


class RepositoryAnalysisAgent:
    """Analyzes repository structure, languages, frameworks, and architecture."""

    def __init__(self):
        self.system_prompt = get_agent_system_prompt("repository_analysis")

    def analyze(self, repo_path: str, supported_extensions: set, max_kb: int = 500) -> Dict:
        """Run full repository analysis."""
        logger.info(f"Starting repository analysis: {repo_path}")

        files, contents = collect_files(repo_path, supported_extensions, max_kb)

        if not files:
            return {"error": "No supported source files found in the repository."}

        # Language distribution
        lang_counter = Counter()
        file_details = []
        total_lines = 0
        total_size = 0

        for filepath in files:
            lang = get_language(filepath)
            content = contents[filepath]
            line_info = count_lines(content)
            lang_counter[lang] += line_info["code"]
            total_lines += line_info["total"]
            total_size += len(content.encode("utf-8"))
            file_details.append({
                "path": filepath,
                "language": lang,
                "lines": line_info,
                "size_bytes": len(content.encode("utf-8")),
                "complexity": calculate_complexity(content, lang),
            })

        # Sort languages by code lines
        language_distribution = [
            {"language": lang, "lines": lines, "percentage": round(lines / max(sum(lang_counter.values()), 1) * 100, 1)}
            for lang, lines in lang_counter.most_common()
        ]

        frameworks = detect_frameworks(files, contents)
        license_type = detect_license(files, contents)
        dependencies = extract_dependencies(contents)
        api_endpoints = detect_api_endpoints(contents)
        file_tree = build_file_tree(repo_path)

        # Config files detection
        config_files = [
            f for f in files
            if any(kw in f.lower() for kw in [
                "config", ".env", "settings", ".yaml", ".yml", ".toml",
                ".json", "dockerfile", "docker-compose", "nginx", "webpack",
                "babel", "jest", "pytest", "setup.py", "pyproject",
            ])
        ]

        # Build AI summary prompt
        summary_context = (
            f"Project has {len(files)} files, {total_lines} total lines.\n"
            f"Languages: {', '.join([f'{l[\"language\"]}({l[\"percentage\"]}%)' for l in language_distribution[:5]])}\n"
            f"Frameworks: {', '.join(frameworks) if frameworks else 'None detected'}\n"
            f"Dependencies: {json.dumps({k: len(v) for k, v in dependencies.items()})}\n"
            f"API Endpoints: {len(api_endpoints)}\n"
            f"Config files: {', '.join(config_files[:10])}\n"
            f"License: {license_type}\n"
            f"Top files by complexity: {json.dumps([{'path': f['path'], 'complexity': f['complexity']} for f in sorted(file_details, key=lambda x: x['complexity'], reverse=True)[:5]])}"
        )

        prompt = (
            f"{self.system_prompt}\n\n"
            f"Analyze this repository and provide a comprehensive summary:\n\n"
            f"{summary_context}\n\n"
            f"File structure sample:\n"
            f"{chr(10).join(files[:30])}\n\n"
            f"Provide:\n"
            f"1. **Executive Summary** (2-3 sentences)\n"
            f"2. **Project Type** (web app, API, CLI, library, microservice, etc.)\n"
            f"3. **Architecture Pattern** (MVC, microservices, monolith, etc.)\n"
            f"4. **Technology Stack** (frontend, backend, database, infrastructure)\n"
            f"5. **Key Observations** (notable design choices, potential concerns)\n"
            f"6. **Health Score** (0-100 with brief justification)\n"
        )

        client = get_watsonx_client()
        ai_summary = client.generate(prompt, use_code_model=False, max_tokens=2048)

        # Health score calculation
        health_score = self._calculate_health_score(
            file_details, frameworks, dependencies, api_endpoints, contents
        )

        return {
            "total_files": len(files),
            "total_lines": total_lines,
            "total_size_kb": round(total_size / 1024, 1),
            "language_distribution": language_distribution,
            "primary_language": language_distribution[0]["language"] if language_distribution else "Unknown",
            "frameworks": frameworks,
            "license": license_type,
            "dependencies": dependencies,
            "api_endpoints": api_endpoints[:50],
            "config_files": config_files[:20],
            "file_tree": file_tree,
            "file_details": file_details[:200],
            "health_score": health_score,
            "ai_summary": ai_summary,
        }

    def _calculate_health_score(self, file_details, frameworks, dependencies, endpoints, contents) -> Dict:
        """Calculate repository health score across multiple dimensions."""
        scores = {}

        # Structure score
        dep_files = {k for k in contents.keys() if any(n in k for n in [
            "requirements.txt", "package.json", "pom.xml", "go.mod", "Cargo.toml"
        ])}
        has_readme = any("readme" in k.lower() for k in contents.keys())
        has_license = any("license" in k.lower() for k in contents.keys())
        has_tests = any("test" in k.lower() or "spec" in k.lower() for k in contents.keys())
        has_ci = any(k.lower() in [".github/workflows", ".travis.yml", "jenkinsfile", ".gitlab-ci.yml"]
                     or ".github" in k.lower() for k in contents.keys())

        structure_score = 50
        if has_readme: structure_score += 15
        if has_license: structure_score += 10
        if has_tests: structure_score += 15
        if has_ci: structure_score += 10
        scores["structure"] = min(structure_score, 100)

        # Complexity score
        if file_details:
            avg_complexity = sum(f["complexity"] for f in file_details) / len(file_details)
            scores["complexity"] = max(0, 100 - int(avg_complexity * 2))
        else:
            scores["complexity"] = 50

        # Dependency score
        total_deps = sum(len(v) for v in dependencies.values())
        scores["dependencies"] = max(0, 100 - max(0, total_deps - 20) * 2)

        # Documentation score
        doc_files = sum(1 for k in contents if k.lower().endswith(".md"))
        scores["documentation"] = min(100, doc_files * 20 + (30 if has_readme else 0))

        overall = int(sum(scores.values()) / len(scores))
        grade = "A" if overall >= 90 else "B" if overall >= 80 else "C" if overall >= 70 else "D" if overall >= 60 else "F"

        return {
            "overall": overall,
            "grade": grade,
            "dimensions": scores,
            "has_readme": has_readme,
            "has_license": has_license,
            "has_tests": has_tests,
            "has_ci": has_ci,
        }
