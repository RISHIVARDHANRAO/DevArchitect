# DevArchitect AI — Multi-Agent Software Engineering Assistant

<div align="center">

![DevArchitect AI Banner](https://img.shields.io/badge/DevArchitect-AI-3b82d4?style=for-the-badge&logo=ibm&logoColor=white)
[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?style=flat-square&logo=python&logoColor=white)](https://python.org)
[![Flask](https://img.shields.io/badge/Flask-3.0-000000?style=flat-square&logo=flask)](https://flask.palletsprojects.com)
[![IBM watsonx.ai](https://img.shields.io/badge/IBM%20watsonx.ai-Granite-052FAD?style=flat-square&logo=ibm)](https://ibm.com/watsonx)
[![License: MIT](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)

**Enterprise-grade AI-powered code intelligence with 8 specialized agents, RAG-based semantic search, and interactive dashboards.**

[🚀 Quick Start](#quick-start) · [📖 Features](#features) · [🤖 Agent Architecture](#agent-architecture) · [⚙️ Configuration](#configuration) · [📸 Screenshots](#screenshots)

</div>

---

## Overview

DevArchitect AI is a production-ready **Multi-Agent Software Engineering Assistant** built with:

- **Python Flask** backend with modular Blueprint architecture
- **IBM watsonx.ai Granite** models (ibm/granite-3-8b-instruct, ibm/granite-34b-code-instruct)
- **FAISS Vector Store** + **Sentence Transformers** for RAG-based semantic search
- **Bootstrap 5** enterprise frontend with Chart.js, Mermaid.js, and dark/light mode
- **8 Specialized AI Agents** for comprehensive code analysis

Upload any ZIP project or connect a public GitHub repository and get instant AI-powered insights.

---

## Features

### Repository Intelligence
- ✅ ZIP project upload (drag & drop)
- ✅ GitHub repository import (URL)
- ✅ Automatic language & framework detection (30+ languages)
- ✅ Dependency analysis (requirements.txt, package.json, pom.xml, go.mod, etc.)
- ✅ Repository health scoring (A–F grade)
- ✅ Technology stack visualization
- ✅ API endpoint discovery
- ✅ Configuration file analysis
- ✅ License detection

### AI Analysis
- ✅ AI-powered repository summarization
- ✅ Architecture diagrams (Mermaid.js)
- ✅ Security vulnerability detection (OWASP Top 10)
- ✅ Code quality metrics & SOLID violations
- ✅ Performance bottleneck analysis (Big-O)
- ✅ Documentation generation (README, API docs, guides)
- ✅ Unit test generation
- ✅ RAG-based Q&A about any file, function, or workflow

### Developer Experience
- ✅ Interactive file explorer with syntax highlighting
- ✅ Multi-turn AI chat with repository context
- ✅ PDF & Markdown report export
- ✅ Dark/Light mode toggle
- ✅ Responsive mobile design
- ✅ Toast notifications
- ✅ Session history

---

## Agent Architecture

```
DevArchitect AI
│
├── 🔍 Repository Analysis Agent  → Language, frameworks, health score, file tree
├── 🏗️  Architecture Agent          → Mermaid diagrams, patterns, module relationships
├── 🛡️  Security Analysis Agent     → OWASP Top 10, CVE, secrets detection
├── ⚡ Performance Agent            → N+1 queries, Big-O, memory, caching
├── 📋 Code Review Agent            → SOLID, code smells, duplication, dead code
├── 📝 Documentation Agent          → README, API docs, install guides
├── 🧪 Test Generation Agent        → Unit tests, integration tests, edge cases
└── 💬 Repository Q&A Agent (RAG)  → FAISS semantic search, multi-turn chat
```

### Agent Instructions

All agent behavior is controlled through [`app/agents/agent_instructions.py`](app/agents/agent_instructions.py):

```python
AGENT_INSTRUCTIONS = {
    "persona": { "expertise_level": "Senior / Principal Engineer", ... },
    "coding_standards": { "max_function_length_lines": 50, ... },
    "security": { "follow_standard": "OWASP, NIST, CWE", ... },
    "review": { "strictness": "strict", ... },
    "documentation": { "style": "Google-style docstrings", ... },
    "optimization": { "priorities": ["correctness", "readability", "performance"], ... },
}
```

---

## Quick Start

### Prerequisites
- Python 3.10+
- IBM Cloud account with watsonx.ai project
- Internet connection (for GitHub imports)

### 1. Clone & Install

```bash
git clone https://github.com/your-org/devarchitect-ai
cd devarchitect-ai
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` with your IBM credentials:

```env
IBM_API_KEY=your_ibm_cloud_api_key
IBM_WATSONX_URL=https://us-south.ml.cloud.ibm.com
IBM_PROJECT_ID=your_watsonx_project_id
```

### 3. Run

```bash
python run.py
```

Visit **http://localhost:5000**

---

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `IBM_API_KEY` | IBM Cloud API Key | Required |
| `IBM_WATSONX_URL` | watsonx.ai endpoint URL | `https://us-south.ml.cloud.ibm.com` |
| `IBM_PROJECT_ID` | watsonx.ai Project ID | Required |
| `GRANITE_MODEL_ID` | Chat model ID | `ibm/granite-3-8b-instruct` |
| `GRANITE_CODE_MODEL_ID` | Code model ID | `ibm/granite-34b-code-instruct` |
| `EMBEDDING_MODEL` | Sentence transformer model | `all-MiniLM-L6-v2` |
| `MAX_UPLOAD_SIZE_MB` | Max ZIP upload size | `100` |
| `RAG_CHUNK_SIZE` | RAG chunking size | `1000` |
| `FLASK_DEBUG` | Enable debug mode | `false` |

### Getting IBM watsonx.ai Credentials

1. Go to [IBM Cloud](https://cloud.ibm.com)
2. Create a **watsonx.ai** service instance
3. Create a **Project** in watsonx.ai
4. Generate an **API Key** from IAM settings
5. Copy your Project ID from the project settings

---

## Project Structure

```
devarchitect-ai/
├── run.py                          # Entry point
├── requirements.txt                # Python dependencies
├── .env.example                    # Environment template
│
├── app/
│   ├── __init__.py                 # Flask app factory
│   ├── config.py                   # Configuration class
│   │
│   ├── agents/
│   │   ├── agent_instructions.py   # ⭐ AGENT BEHAVIOR CONFIG
│   │   ├── repo_analysis_agent.py  # Repository Analysis Agent
│   │   ├── architecture_agent.py   # Architecture Agent
│   │   ├── code_review_agent.py    # Code Review Agent
│   │   ├── security_agent.py       # Security Analysis Agent
│   │   ├── performance_agent.py    # Performance Agent
│   │   ├── documentation_agent.py  # Documentation Agent
│   │   ├── test_generation_agent.py# Test Generation Agent
│   │   └── rag_qa_agent.py         # RAG Q&A Agent
│   │
│   ├── blueprints/
│   │   ├── main.py                 # Page routes
│   │   ├── api.py                  # General API endpoints
│   │   ├── agents.py               # Agent endpoints
│   │   └── repo.py                 # Upload/import endpoints
│   │
│   ├── services/
│   │   ├── rag_service.py          # FAISS vector store
│   │   ├── report_service.py       # PDF generation
│   │   └── session_service.py      # Session management
│   │
│   ├── utils/
│   │   ├── watsonx_client.py       # IBM watsonx.ai wrapper
│   │   ├── repo_parser.py          # Repository parsing
│   │   ├── git_utils.py            # GitHub & ZIP utilities
│   │   └── logger.py               # Structured logging
│   │
│   ├── templates/
│   │   ├── base.html               # Base template (sidebar, navbar)
│   │   ├── index.html              # Home / upload page
│   │   ├── dashboard.html          # Analysis dashboard
│   │   └── chat.html               # AI Chat interface
│   │
│   └── static/
│       ├── css/main.css            # Enterprise UI styles
│       └── js/
│           ├── app.js              # Shared logic, theme, utilities
│           ├── dashboard.js        # Dashboard interactions & charts
│           └── chat.js             # Chat interface logic
│
├── uploads/                        # ZIP upload staging
├── repos/                          # Extracted repositories
├── reports/                        # Generated PDF/Markdown reports
├── vector_store/                   # FAISS index files
└── logs/                           # Application logs
```

---

## API Reference

### Repository Management
| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/repo/upload` | Upload ZIP project |
| `POST` | `/api/repo/github` | Import GitHub repository |
| `POST` | `/api/repo/filetree` | Get file tree structure |

### AI Agents
| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/agents/analyze/repository` | Repository analysis |
| `POST` | `/api/agents/analyze/architecture` | Architecture analysis |
| `POST` | `/api/agents/analyze/security` | Security analysis |
| `POST` | `/api/agents/analyze/performance` | Performance analysis |
| `POST` | `/api/agents/analyze/code-review` | Code review |
| `POST` | `/api/agents/analyze/documentation` | Documentation generation |
| `POST` | `/api/agents/analyze/tests` | Test generation |
| `POST` | `/api/agents/analyze/all` | Run all agents |
| `POST` | `/api/agents/chat` | Multi-turn RAG chat |
| `POST` | `/api/agents/explain/file` | Explain specific file |
| `POST` | `/api/agents/report/generate` | Generate PDF report |
| `GET` | `/api/agents/report/download/<file>` | Download report |

### System
| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/status` | Health check + watsonx.ai status |
| `POST` | `/api/config/validate` | Validate IBM credentials |
| `GET` | `/api/sessions` | List all sessions |
| `DELETE` | `/api/sessions/<id>` | Delete session |

---

## Deployment

### Development

```bash
python run.py
```

### Production with Gunicorn

```bash
gunicorn -w 4 -b 0.0.0.0:5000 --timeout 300 "run:app"
```

### Docker

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "--timeout", "300", "run:app"]
```

```bash
docker build -t devarchitect-ai .
docker run -p 5000:5000 --env-file .env devarchitect-ai
```

---

## Customizing Agent Behavior

Edit [`app/agents/agent_instructions.py`](app/agents/agent_instructions.py) to customize:

- **Review strictness**: `"lenient"`, `"moderate"`, `"strict"`, `"pedantic"`
- **Max function length**: `max_function_length_lines`
- **Cyclomatic complexity threshold**: `max_cyclomatic_complexity`
- **Documentation style**: Google-style, JSDoc, etc.
- **Security standards**: OWASP, NIST, CWE coverage
- **Explanation depth**: `"brief"`, `"standard"`, `"comprehensive"`, `"expert"`
- **Optimization priorities**: order of correctness/readability/performance

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| Backend | Python 3.10+, Flask 3.0, Flask-CORS |
| AI/ML | IBM watsonx.ai Granite, Sentence Transformers |
| Vector Store | FAISS (faiss-cpu) |
| Frontend | Bootstrap 5, Chart.js, Mermaid.js, Highlight.js |
| Analysis | Radon, Bandit, AST parsing |
| Reports | ReportLab (PDF), Markdown |
| Deployment | Gunicorn, Docker |

---

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -am 'Add my feature'`
4. Push and open a Pull Request

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

<div align="center">
<strong>DevArchitect AI</strong> · Powered by IBM watsonx.ai Granite · Built with ❤️
</div>
